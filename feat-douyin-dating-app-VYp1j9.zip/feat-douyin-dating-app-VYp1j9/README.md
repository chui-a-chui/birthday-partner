# 生日搭子项目

这是一份完整的生日搭子社交产品源代码。

## 📂 项目结构

```
birthday-partner/
├── apps/
│   └── h5/                      # H5移动端（Vue 3 + Vite）
├── packages/
│   ├── shared/                  # 共享类型定义
│   └── api-client/              # API客户端
├── server/                      # 后端服务（NestJS）
├── docs/                        # 文档
├── package.json                 # 根目录package.json
└── README.md                    # 项目说明
```

## 🚀 快速开始

### 1. 安装依赖
```bash
pnpm install
```

### 2. 启动开发服务器
```bash
# 启动后端
pnpm --filter @birthday-partner/server start:dev

# 启动前端
pnpm --filter @birthday-partner/h5 dev
```

### 3. 访问应用
- H5应用: http://localhost:5173
- API文档: http://localhost:3000/api/docs

## 📱 技术栈

- **前端**: Vue 3 + Vite + TypeScript + Pinia + Vant
- **后端**: NestJS + MongoDB + Redis
- **部署**: Docker, Railway, Vercel

## ☁️ 部署

详见 docs/superpowers/plans/ 目录下的部署文档。

## 📄 许可证

MIT License
