import { request } from '@birthday-partner/api-client';
import { API_PATHS } from '@birthday-partner/shared';

export interface Partner {
  id: string;
  nickname: string;
  avatar: string;
  birthday: string;
  gender: string;
  city: string;
  interests: string[];
  bio: string;
}

export interface TodayPartnersResponse {
  total: number;
  today: string;
  list: Partner[];
}

export interface GreetResponse {
  code: number;
  message: string;
}

export const getTodayPartners = (
  userId: string,
  page = 1,
  pageSize = 20,
  filters?: { city?: string; gender?: string }
) => {
  return request.get<TodayPartnersResponse>(API_PATHS.PARTNERS.TODAY, {
    params: { userId, page, pageSize, ...filters },
  });
};

export const sendGreet = (
  fromUserId: string,
  toUserId: string,
  content?: string
) => {
  return request.post<GreetResponse>(API_PATHS.PARTNERS.GREET, {
    fromUserId,
    toUserId,
    content,
  });
};

export const getGreetings = (
  userId: string,
  type: 'sent' | 'received',
  page = 1,
  pageSize = 20
) => {
  return request.get<any>(API_PATHS.PARTNERS.GREETINGS, {
    params: { userId, type, page, pageSize },
  });
};
