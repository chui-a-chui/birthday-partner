import { request } from '@birthday-partner/api-client';
import { API_PATHS } from '@birthday-partner/shared';
import type { User, UserLoginResponse, UserProfile } from '@birthday-partner/shared';

export const login = (code: string, platform: string) => {
  return request.post<UserLoginResponse>(API_PATHS.USERS.LOGIN, {
    code,
    platform,
  });
};

export const getUserProfile = (userId: string) => {
  return request.get<UserProfile>(`${API_PATHS.USERS.PROFILE}/${userId}`);
};

export const updateUserProfile = (id: string, data: Partial<User>) => {
  return request.put<User>(API_PATHS.USERS.UPDATE_PROFILE, {
    id,
    ...data,
  });
};

export const updateLocation = (
  id: string,
  location: {
    latitude: number;
    longitude: number;
    province: string;
    city: string;
    district: string;
  }
) => {
  return request.put<User>(API_PATHS.USERS.UPDATE_LOCATION, {
    id,
    ...location,
  });
};
