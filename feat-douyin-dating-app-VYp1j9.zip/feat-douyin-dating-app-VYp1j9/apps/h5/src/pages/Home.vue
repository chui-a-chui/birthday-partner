<template>
  <div class="home-page">
    <van-nav-bar title="生日搭子" fixed>
      <template #right>
        <van-icon name="filter-o" size="18" @click="showFilters = true" />
      </template>
    </van-nav-bar>

    <div class="content">
      <div class="header-info">
        <h2>🎂 今日寿星</h2>
        <p>今天有 {{ total }} 位寿星和你同一天生日</p>
      </div>

      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model:loading="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <van-cell v-for="item in list" :key="item.id" class="partner-item">
            <div class="partner-card">
              <van-image
                round
                width="50"
                height="50"
                :src="item.avatar || defaultAvatar"
              />
              <div class="partner-info">
                <div class="name">{{ item.nickname }}</div>
                <div class="meta">
                  <span>📍 {{ item.city }}</span>
                  <span>🎂 {{ formatBirthday(item.birthday) }}</span>
                </div>
                <div class="bio" v-if="item.bio">{{ item.bio }}</div>
                <div class="interests">
                  <van-tag
                    v-for="interest in item.interests.slice(0, 3)"
                    :key="interest"
                    type="primary"
                    size="small"
                  >
                    {{ interest }}
                  </van-tag>
                </div>
              </div>
              <van-button
                size="small"
                type="primary"
                :loading="greetingId === item.id"
                @click="handleGreet(item)"
              >
                💌 搭话
              </van-button>
            </div>
          </van-cell>
        </van-list>
      </van-pull-refresh>

      <van-empty v-if="!loading && list.length === 0" description="暂无今日寿星" />
    </div>

    <van-popup v-model:show="showFilters" position="top" :style="{ height: 'auto' }">
      <van-cell-group title="筛选条件">
        <van-cell title="性别">
          <template #value>
            <van-radio-group v-model="filters.gender" direction="horizontal">
              <van-radio name="">不限</van-radio>
              <van-radio name="male">男</van-radio>
              <van-radio name="female">女</van-radio>
            </van-radio-group>
          </template>
        </van-cell>
      </van-cell-group>
      <div style="padding: 16px;">
        <van-button block type="primary" @click="applyFilters">应用筛选</van-button>
      </div>
    </van-popup>

    <van-tabbar route fixed>
      <van-tabbar-item to="/home" icon="friends-o">发现搭子</van-tabbar-item>
      <van-tabbar-item to="/profile" icon="user-o">个人中心</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed, onMounted } from 'vue';
import { showToast } from 'vant';
import { useUserStore } from '../stores/user';
import { getTodayPartners, sendGreet, type Partner } from '../api/partners';

const userStore = useUserStore();

const list = ref<Partner[]>([]);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const greetingId = ref<string | null>(null);
const showFilters = ref(false);
const page = ref(1);
const total = ref(0);
const defaultAvatar = 'https://fastly.jsdelivr.net/npm/@vant/assets/cat.jpeg';

const filters = reactive({
  gender: '',
  city: '',
});

const currentUserId = computed(() => userStore.userInfo?.id || '');

const formatBirthday = (date: string) => {
  const d = new Date(date);
  return `${d.getMonth() + 1}月${d.getDate()}日`;
};

const fetchData = async () => {
  try {
    const result = await getTodayPartners(
      currentUserId.value,
      page.value,
      20,
      {
        gender: filters.gender || undefined,
        city: filters.city || undefined,
      }
    );

    if (page.value === 1) {
      list.value = result.list;
    } else {
      list.value.push(...result.list);
    }

    total.value = result.total;

    if (list.value.length >= result.total) {
      finished.value = true;
    } else {
      page.value++;
    }
  } catch (error) {
    console.error('获取今日寿星失败', error);
    finished.value = true;
  } finally {
    loading.value = false;
  }
};

const onLoad = async () => {
  if (refreshing.value) {
    return;
  }
  await fetchData();
};

const onRefresh = async () => {
  list.value = [];
  page.value = 1;
  finished.value = false;
  loading.value = true;
  await fetchData();
  refreshing.value = false;
  showToast('刷新成功');
};

const applyFilters = () => {
  showFilters.value = false;
  onRefresh();
};

const handleGreet = async (item: Partner) => {
  if (!currentUserId.value) {
    showToast('请先登录');
    return;
  }

  greetingId.value = item.id;

  try {
    await sendGreet(currentUserId.value, item.id);
    showToast('搭话成功，等待对方回复~');
  } catch (error) {
    showToast('搭话失败，请重试');
  } finally {
    greetingId.value = null;
  }
};

onMounted(() => {
  if (!userStore.isLoggedIn) {
    // 已经在路由守卫中处理
  }
});
</script>

<style scoped>
.home-page {
  min-height: 100vh;
  background: #f5f5f5;
  padding-top: 46px;
  padding-bottom: 50px;
}

.content {
  padding: 12px;
}

.header-info {
  text-align: center;
  padding: 20px 0;
}

.header-info h2 {
  font-size: 24px;
  color: #FF6B6B;
  margin-bottom: 8px;
}

.header-info p {
  font-size: 14px;
  color: #666;
}

.partner-card {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 8px 0;
}

.partner-info {
  flex: 1;
  min-width: 0;
}

.name {
  font-size: 16px;
  font-weight: 600;
  color: #333;
}

.meta {
  font-size: 12px;
  color: #666;
  margin: 4px 0;
  display: flex;
  gap: 12px;
}

.bio {
  font-size: 12px;
  color: #999;
  margin: 4px 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.interests {
  display: flex;
  gap: 4px;
  margin-top: 4px;
  flex-wrap: wrap;
}
</style>
