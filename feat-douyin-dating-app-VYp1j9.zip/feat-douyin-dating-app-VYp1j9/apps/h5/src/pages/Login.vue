<template>
  <div class="login-page">
    <div class="logo">
      <h1>🎂 生日搭子</h1>
      <p>生日不孤单，同城找搭子</p>
    </div>

    <div class="login-form">
      <van-cell-group inset>
        <van-field
          v-model="nickname"
          label="昵称"
          placeholder="请输入昵称"
          :rules="[{ required: true, message: '请输入昵称' }]"
        />
        <van-field
          v-model="birthday"
          is-link
          readonly
          label="生日"
          placeholder="请选择生日"
          @click="showBirthdayPicker = true"
        />
        <van-field name="gender" label="性别">
          <template #input>
            <van-radio-group v-model="gender" direction="horizontal">
              <van-radio name="male">男</van-radio>
              <van-radio name="female">女</van-radio>
              <van-radio name="secret">保密</van-radio>
            </van-radio-group>
          </template>
        </van-field>
      </van-cell-group>

      <div style="margin: 16px;">
        <van-button
          round
          block
          type="primary"
          :loading="loading"
          @click="handleLogin"
        >
          登录
        </van-button>
      </div>
    </div>

    <van-popup v-model:show="showBirthdayPicker" position="bottom">
      <van-date-picker
        v-model="currentDate"
        :min-date="minDate"
        :max-date="maxDate"
        @confirm="onConfirmBirthday"
      />
    </van-popup>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { showToast } from 'vant';
import { useUserStore } from '../stores/user';

const router = useRouter();
const userStore = useUserStore();

const nickname = ref('');
const birthday = ref('');
const gender = ref('secret');
const loading = ref(false);
const showBirthdayPicker = ref(false);
const currentDate = ref(['2000', '01', '01']);

const minDate = new Date(1970, 0, 1);
const maxDate = new Date();

const onConfirmBirthday = ({ selectedValues }: { selectedValues: string[] }) => {
  birthday.value = selectedValues.join('-');
  showBirthdayPicker.value = false;
};

const handleLogin = async () => {
  if (!nickname.value) {
    showToast('请输入昵称');
    return;
  }
  if (!birthday.value) {
    showToast('请选择生日');
    return;
  }

  loading.value = true;

  try {
    const mockToken = `token_${Date.now()}`;
    const mockUser = {
      id: `user_${Date.now()}`,
      openid: `openid_${Date.now()}`,
      nickname: nickname.value,
      avatar: '',
      birthday: birthday.value,
      gender: gender.value,
      bio: '',
      interests: [],
      location: {
        province: '',
        city: '',
        district: '',
        latitude: 0,
        longitude: 0,
        geohash: '',
      },
      status: 1,
    };

    userStore.setToken(mockToken);
    userStore.setUserInfo(mockUser as any);

    showToast('登录成功');
    router.push('/home');
  } catch (error) {
    showToast('登录失败');
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 20px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FFA07A 100%);
}

.logo {
  text-align: center;
  margin-bottom: 40px;
}

.logo h1 {
  font-size: 32px;
  color: white;
  margin-bottom: 12px;
}

.logo p {
  font-size: 16px;
  color: rgba(255, 255, 255, 0.9);
}

.login-form {
  background: white;
  border-radius: 16px;
  padding: 20px 0;
}
</style>
