<template>
  <div class="profile-page">
    <van-nav-bar title="个人中心" fixed />

    <div class="content">
      <van-cell-group inset>
        <van-cell title="头像">
          <template #value>
            <van-image
              round
              width="50"
              height="50"
              :src="userInfo?.avatar || defaultAvatar"
            />
          </template>
        </van-cell>
        <van-cell title="昵称" :value="userInfo?.nickname || '-'" />
        <van-cell title="生日" :value="formatBirthday(userInfo?.birthday)" />
        <van-cell title="性别" :value="formatGender(userInfo?.gender)" />
      </van-cell-group>

      <van-cell-group inset title="兴趣标签" style="margin-top: 12px;">
        <van-cell title="我的兴趣" is-link>
          <template #value>
            <span v-if="userInfo?.interests?.length">
              {{ userInfo.interests.slice(0, 3).join(', ') }}
            </span>
            <span v-else>未设置</span>
          </template>
        </van-cell>
        <van-cell title="位置权限" is-link @click="updateLocation">
          <template #value>
            <span v-if="userInfo?.location?.city">{{ userInfo.location.city }}</span>
            <span v-else>未设置</span>
          </template>
        </van-cell>
      </van-cell-group>

      <van-cell-group inset title="统计" style="margin-top: 12px;">
        <van-cell title="收到的搭话" :value="'0'" />
        <van-cell title="发出的搭话" :value="'0'" />
      </van-cell-group>

      <div style="margin: 20px;">
        <van-button block type="default" @click="handleLogout">
          退出登录
        </van-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRouter } from 'vue-router';
import { showToast, Dialog } from 'vant';
import { useUserStore } from '../stores/user';

const router = useRouter();
const userStore = useUserStore();

const userInfo = computed(() => userStore.userInfo);
const defaultAvatar = 'https://fastly.jsdelivr.net/npm/@vant/assets/cat.jpeg';

const formatBirthday = (date?: string) => {
  if (!date) return '-';
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const formatGender = (gender?: string) => {
  const map: Record<string, string> = {
    male: '男',
    female: '女',
    secret: '保密',
  };
  return map[gender || 'secret'] || '-';
};

const updateLocation = () => {
  showToast('位置更新成功');
};

const handleLogout = () => {
  Dialog.confirm({
    title: '提示',
    message: '确定要退出登录吗？',
  })
    .then(() => {
      userStore.logout();
      showToast('已退出登录');
      router.push('/login');
    })
    .catch(() => {});
};
</script>

<style scoped>
.profile-page {
  min-height: 100vh;
  background: #f5f5f5;
  padding-top: 46px;
}

.content {
  padding: 12px;
}
</style>
