import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { User } from '@birthday-partner/shared';

export const useUserStore = defineStore('user', () => {
  const token = ref<string>(localStorage.getItem('token') || '');
  const userInfo = ref<User | null>(null);

  const isLoggedIn = computed(() => !!token.value);
  const isNewUser = computed(() => userInfo.value?.bio === '');

  function setToken(newToken: string) {
    token.value = newToken;
    localStorage.setItem('token', newToken);
  }

  function setUserInfo(info: User) {
    userInfo.value = info;
  }

  function updateUserInfo(updates: Partial<User>) {
    if (userInfo.value) {
      userInfo.value = { ...userInfo.value, ...updates };
    }
  }

  function logout() {
    token.value = '';
    userInfo.value = null;
    localStorage.removeItem('token');
  }

  return {
    token,
    userInfo,
    isLoggedIn,
    isNewUser,
    setToken,
    setUserInfo,
    updateUserInfo,
    logout,
  };
});
