# 生日搭子 - 技术规格文档

**版本**: v1.0  
**日期**: 2026-05-08  
**状态**: 待用户审核  
**目标**: 为"生日搭子"MVP产品提供完整的技术规格指导

---

## 一、技术栈选型

### 1.1 整体技术架构

| 层级 | 技术选型 | 版本要求 | 说明 |
|------|---------|---------|------|
| **前端-H5** | Vue 3 + Vite | ^3.4 | 快速构建、优化打包 |
| **前端-类型** | TypeScript | ^5.0 | 类型安全、提高代码质量 |
| **前端-状态** | Pinia | ^2.1 | Vue 3 推荐状态管理 |
| **前端-UI库** | Vant 4 | ^4.0 | 轻量级移动端UI组件 |
| **小程序** | 抖音小程序 | 最新版 | 使用Vue 3语法 |
| **后端** | NestJS | ^10.0 | 结构清晰、可扩展性强 |
| **数据库** | MongoDB | ^6.0 | 灵活的数据模型 |
| **缓存/Geo** | Redis | ^7.0 | 地理位置计算、会话缓存 |
| **部署** | Docker | ^24.0 | 容器化部署 |
| **云服务** | 阿里云/腾讯云 | - | 国内服务器、备案域名 |

### 1.2 技术选型理由

#### 为什么选择NestJS而不是Express？

| 对比项 | NestJS | Express |
|--------|--------|---------|
| **代码组织** | 模块化（Modules） | 自由但易混乱 |
| **类型安全** | 深度TypeScript集成 | 需手动配置 |
| **可测试性** | 内置依赖注入 | 需手动注入 |
| **学习曲线** | 中等 | 低 |
| **适合场景** | 中大型项目 | 快速原型 |

**结论**：个人开发者且需要快速迭代，NestJS的模块化结构能保持代码清晰，同时提供企业级的可扩展性。

#### 为什么选择MongoDB而不是MySQL？

| 对比项 | MongoDB | MySQL |
|--------|---------|-------|
| **数据模型** | 文档型，灵活 | 关系型，需预先设计 |
| **地理位置** | 原生GeoJSON支持 | 需扩展 |
| **社交场景** | 用户资料、动态灵活存储 | 需多表关联 |
| **扩展性** | 水平扩展简单 | 需分库分表 |

**结论**：社交产品数据结构变化快，MongoDB的灵活性更适合MVP阶段快速迭代。

---

## 二、项目架构设计

### 2.1 Monorepo项目结构

```
birthday-partner/
├── apps/                           # 应用层
│   ├── h5/                         # H5移动端应用
│   │   ├── src/
│   │   │   ├── api/               # API调用层
│   │   │   ├── assets/            # 静态资源
│   │   │   ├── components/        # 业务组件
│   │   │   ├── composables/       # 组合式函数
│   │   │   ├── pages/             # 页面
│   │   │   ├── router/            # 路由配置
│   │   │   ├── stores/            # Pinia状态管理
│   │   │   ├── styles/            # 全局样式
│   │   │   ├── types/             # 类型定义
│   │   │   ├── utils/             # 工具函数
│   │   │   ├── App.vue
│   │   │   └── main.ts
│   │   ├── index.html
│   │   ├── vite.config.ts
│   │   ├── tsconfig.json
│   │   └── package.json
│   │
│   └── miniprogram/               # 抖音小程序应用
│       ├── src/
│       │   ├── api/               # API调用层（复用shared）
│       │   ├── components/        # 业务组件
│       │   ├── pages/             # 页面
│       │   ├── styles/            # 样式
│       │   └── app.json
│       ├── project.config.json
│       └── package.json
│
├── packages/                       # 共享包层
│   ├── shared/                    # 核心共享代码
│   │   ├── src/
│   │   │   ├── types/            # 共享类型定义
│   │   │   │   ├── user.ts
│   │   │   │   ├── activity.ts
│   │   │   │   └── index.ts
│   │   │   ├── constants/        # 常量定义
│   │   │   │   ├── api.ts        # API路径常量
│   │   │   │   └── config.ts     # 全局配置
│   │   │   ├── utils/            # 工具函数
│   │   │   │   ├── date.ts       # 日期处理
│   │   │   │   ├── format.ts     # 格式化工具
│   │   │   │   └── validate.ts   # 验证工具
│   │   │   └── index.ts
│   │   ├── package.json
│   │   └── tsconfig.json
│   │
│   └── api-client/                # API客户端封装
│       ├── src/
│       │   ├── request.ts        # axios封装
│       │   ├── methods.ts        # HTTP方法封装
│       │   └── interceptors.ts   # 拦截器
│       ├── package.json
│       └── tsconfig.json
│
├── server/                         # 后端服务
│   ├── src/
│   │   ├── main.ts               # 入口文件
│   │   ├── app.module.ts         # 根模块
│   │   │
│   │   ├── common/               # 公共模块
│   │   │   ├── decorators/       # 自定义装饰器
│   │   │   ├── filters/          # 异常过滤器
│   │   │   ├── guards/           # 守卫
│   │   │   ├── interceptors/     # 拦截器
│   │   │   ├── pipes/            # 管道
│   │   │   └── dto/              # 公共DTO
│   │   │
│   │   ├── config/               # 配置文件
│   │   │   ├── index.ts
│   │   │   ├── database.config.ts
│   │   │   ├── redis.config.ts
│   │   │   └── app.config.ts
│   │   │
│   │   └── modules/               # 业务模块
│   │       ├── users/            # 用户模块
│   │       ├── partners/        # 搭子/匹配模块
│   │       ├── activities/      # 活动模块
│   │       └── messages/         # 消息模块
│   │
│   ├── test/                      # 测试文件
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── package.json
│   └── tsconfig.json
│
├── docs/                          # 文档目录
│   ├── design/                   # 产品设计文档
│   └── specs/                   # 技术设计文档
│
├── .gitignore
├── package.json                  # 根目录package.json
├── pnpm-workspace.yaml           # pnpm workspace配置
├── tsconfig.base.json           # 基础TS配置
└── README.md
```

### 2.2 模块职责划分

#### 前端应用层 (apps/)

| 模块 | 职责 | 技术要点 |
|------|------|---------|
| **h5** | H5移动端应用 | Vue 3 + Vite，移动端适配，响应式布局 |
| **miniprogram** | 抖音小程序 | 小程序特有API适配，组件库选择 |

#### 共享包层 (packages/)

| 模块 | 职责 | 使用场景 |
|------|------|---------|
| **shared** | 类型定义、工具函数、常量 | 所有项目共享，确保类型一致 |
| **api-client** | HTTP请求封装、统一错误处理 | H5和小程序共用后端接口调用 |

#### 后端模块层 (server/modules/)

| 模块 | 职责 | 包含功能 |
|------|------|---------|
| **users** | 用户管理 | 注册、登录、资料管理 |
| **partners** | 搭子匹配 | 今日寿星、推荐、搭话 |
| **activities** | 活动管理 | 发布、报名、打卡 |
| **messages** | 私信消息 | 搭话记录、私信聊天 |

---

## 三、数据库设计

### 3.1 MongoDB Schema设计

#### 用户集合 (users)

```typescript
// 文件位置: server/src/modules/users/schemas/user.schema.ts

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ timestamps: true, collection: 'users' })
export class User extends Document {
  @Prop({ required: true, unique: true })
  openid: string;                    // 微信/抖音openid（唯一标识）

  @Prop({ required: true, minlength: 2, maxlength: 12 })
  nickname: string;                  // 昵称

  @Prop({ default: '' })
  avatar: string;                    // 头像URL

  @Prop({ required: true, type: Date })
  birthday: Date;                    // 生日（精确到日）

  @Prop({ required: true, enum: ['male', 'female', 'secret'] })
  gender: string;                    // 性别

  @Prop({ default: '' })
  bio: string;                       // 自我介绍（100字内）

  @Prop({ type: [String], default: [] })
  interests: string[];               // 兴趣标签（最多5个）

  @Prop({ required: true, type: Object })
  location: {
    province: string;                // 省
    city: string;                    // 市
    district: string;                // 区
    latitude: number;                // 纬度
    longitude: number;               // 经度
    geohash: string;                 // GeoHash编码
    lastUpdated: Date;              // 最后更新时间
  };

  @Prop({ type: Object, default: null })
  background: {
    school: {
      name: string;                  // 学校名称
      type: string;                  // 类型: 高中/大学/研究生
      level: string;                 // 学历: 本科/硕士/博士
      graduationYear: number;        // 毕业年份
    } | null;
    education: {
      degree: string;                // 学历
      major: string;                 // 专业
    } | null;
    work: {
      company: string;               // 公司名称
      position: string;              // 职位
      industry: string;              // 行业
      isStudent: boolean;            // 是否学生
    } | null;
  };

  @Prop({ default: Date.now })
  lastActiveAt: Date;                // 最后活跃时间

  @Prop({ default: 1, enum: [0, 1] })
  status: number;                    // 状态: 0-禁用 1-正常
}

export const UserSchema = SchemaFactory.createForClass(User);

// 索引设计
UserSchema.index({ birthday: 1 });          // 今日寿星查询
UserSchema.index({ 'location.geohash': 1 }); // 地理位置查询
UserSchema.index({ openid: 1 }, { unique: true }); // openid唯一
UserSchema.index({ status: 1 });            // 状态筛选
```

#### 搭话记录集合 (greetings)

```typescript
// 文件位置: server/src/modules/partners/schemas/greeting.schema.ts

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ timestamps: true, collection: 'greetings' })
export class Greeting extends Document {
  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  fromUserId: Types.ObjectId;        // 发送者ID

  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  toUserId: Types.ObjectId;          // 接收者ID

  @Prop({ required: true })
  content: string;                   // 搭话内容

  @Prop({ default: 0, enum: [0, 1, 2] })
  status: number;                    // 状态: 0-未读 1-已读 2-已回复

  @Prop({ default: Date.now })
  readAt: Date;                       // 阅读时间
}

export const GreetingSchema = SchemaFactory.createForClass(Greeting);

// 索引设计
GreetingSchema.index({ fromUserId: 1 });    // 查询我发送的搭话
GreetingSchema.index({ toUserId: 1 });      // 查询我收到的搭话
GreetingSchema.index({ toUserId: 1, status: 1 }); // 未读搭话查询
GreetingSchema.index({ createdAt: -1 });    // 时间排序
```

#### 活动集合 (activities)

```typescript
// 文件位置: server/src/modules/activities/schemas/activity.schema.ts

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ timestamps: true, collection: 'activities' })
export class Activity extends Document {
  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  organizerId: Types.ObjectId;       // 发起人ID

  @Prop({ required: true, enum: ['meal', 'shopping', 'entertainment', 'sports', 'travel', 'birthday', 'photo'] })
  type: string;                      // 活动类型

  @Prop({ required: true, minlength: 5, maxlength: 30 })
  title: string;                     // 活动标题

  @Prop({ default: '', maxlength: 200 })
  description: string;               // 活动描述

  @Prop({ required: true })
  time: Date;                        // 活动时间

  @Prop({ required: true, type: Object })
  location: {
    name: string;                    // 地点名称
    address: string;                 // 详细地址
    latitude: number;                // 纬度
    longitude: number;               // 经度
  };

  @Prop({ required: true, min: 2, max: 50 })
  maxParticipants: number;          // 最大参与人数

  @Prop({ type: [Types.ObjectId], ref: 'User', default: [] })
  participants: Types.ObjectId[];    // 已报名用户ID列表

  @Prop({ type: [String], default: [] })
  tags: string[];                    // 活动标签

  @Prop({ default: 1, enum: [0, 1, 2] })
  status: number;                    // 状态: 0-已取消 1-进行中 2-已完成
}

export const ActivitySchema = SchemaFactory.createForClass(Activity);

// 索引设计
ActivitySchema.index({ organizerId: 1 });   // 查询我发起的活动
ActivitySchema.index({ time: 1 });          // 按时间查询
ActivitySchema.index({ type: 1 });          // 按类型查询
ActivitySchema.index({ 'location.latitude': 1, 'location.longitude': 1 }); // 附近活动
ActivitySchema.index({ status: 1 });        // 状态筛选
```

#### 打卡记录集合 (checkins)

```typescript
// 文件位置: server/src/modules/activities/schemas/checkin.schema.ts

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ timestamps: true, collection: 'checkins' })
export class Checkin extends Document {
  @Prop({ required: true, type: Types.ObjectId, ref: 'Activity' })
  activityId: Types.ObjectId;        // 活动ID

  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  userId: Types.ObjectId;            // 用户ID

  @Prop({ type: [String], default: [] })
  photos: string[];                  // 打卡照片URL列表

  @Prop({ default: '', maxlength: 200 })
  review: string;                    // 打卡感想

  @Prop({ required: true, min: 1, max: 5 })
  rating: number;                    // 评分 1-5分
}

export const CheckinSchema = SchemaFactory.createForClass(Checkin);

// 索引设计
CheckinSchema.index({ activityId: 1 });    // 查询活动的打卡
CheckinSchema.index({ userId: 1 });        // 查询用户的打卡
CheckinSchema.index({ activityId: 1, userId: 1 }, { unique: true }); // 防止重复打卡
```

### 3.2 Redis数据结构设计

#### 地理位置索引 (GeoHash)

```bash
# 用户位置集合
GEOADD user:locations <longitude> <latitude> <userId>

# 查询附近用户（10公里范围内）
GEORADIUS user:locations <longitude> <latitude> 10 km WITHDIST ASC COUNT 50

# 查询特定用户的距离
GEODIST user:locations <userId1> <userId2> km
```

#### 会话Token缓存

```bash
# 用户会话存储（24小时过期）
SETEX session:<token> 86400 <userId>

# 用户在线状态
SETEX online:<userId> 300 1  # 5分钟过期
```

#### 今日寿星缓存

```bash
# 今日寿星列表（每日凌晨更新）
SET birthday:today:<YYYY-MM-DD> <userId1>,<userId2>,... EX 86400

# 获取今日寿星
GET birthday:today:2026-05-08
```

---

## 四、API接口设计

### 4.1 API规范

#### 基础信息

| 项目 | 说明 |
|------|------|
| **Base URL** | `https://api.birthdaypartner.com` |
| **协议** | HTTPS |
| **数据格式** | JSON |
| **编码** | UTF-8 |
| **认证方式** | Bearer Token |

#### 通用请求头

```
Content-Type: application/json
Authorization: Bearer <token>
X-Platform: h5 | miniprogram
X-Version: 1.0.0
```

#### 通用响应格式

```typescript
// 成功响应
{
  "code": 0,
  "message": "success",
  "data": { ... }
}

// 错误响应
{
  "code": 10001,
  "message": "错误信息",
  "data": null
}
```

#### 错误码定义

| 错误码 | 说明 |
|--------|------|
| 0 | 成功 |
| 10001 | 参数错误 |
| 10002 | 认证失败 |
| 10003 | Token过期 |
| 20001 | 用户不存在 |
| 20002 | 用户已被禁用 |
| 30001 | 活动不存在 |
| 30002 | 活动已满员 |
| 30003 | 已报名该活动 |
| 40001 | 今日搭话次数已用完 |

### 4.2 用户模块API

#### 4.2.1 微信/抖音登录

```
POST /api/users/login
```

**请求体**

```typescript
{
  code: string;        // 微信/抖音登录code（必填）
  platform: 'wechat' | 'douyin';  // 平台类型
}
```

**响应**

```typescript
{
  code: 0,
  message: 'success',
  data: {
    token: string;          // JWT Token
    userInfo: {
      id: string;
      nickname: string;
      avatar: string;
      birthday: string;
      gender: string;
      isNewUser: boolean;   // 是否新用户
    }
  }
}
```

#### 4.2.2 获取用户资料

```
GET /api/users/profile/:userId
```

**响应**

```typescript
{
  code: 0,
  data: {
    id: string;
    nickname: string;
    avatar: string;
    birthday: string;
    gender: string;
    bio: string;
    interests: string[];
    location: {
      province: string;
      city: string;
      district: string;
    };
    background: {
      school: { name: string; type: string } | null;
      work: { company: string; position: string } | null;
    };
    isSameBirthday: boolean;      // 是否同年同月同日
    isSameCity: boolean;          // 是否同城
    commonInterests: string[];    // 共同兴趣
    greetingCount: number;        // 搭话次数
  }
}
```

#### 4.2.3 更新用户资料

```
PUT /api/users/profile
```

**请求体**

```typescript
{
  nickname?: string;
  avatar?: string;
  bio?: string;
  interests?: string[];
}
```

#### 4.2.4 更新位置信息

```
PUT /api/users/location
```

**请求体**

```typescript
{
  latitude: number;      // 纬度
  longitude: number;     // 经度
  province: string;      // 省
  city: string;          // 市
  district: string;      // 区
}
```

### 4.3 搭子模块API

#### 4.3.1 获取今日寿星列表

```
GET /api/partners/today
```

**Query参数**

```typescript
{
  page?: number;         // 页码（默认1）
  pageSize?: number;     // 每页数量（默认20，最大50）
  city?: string;         // 城市筛选（可选）
  gender?: string;       // 性别筛选（可选）
}
```

**响应**

```typescript
{
  code: 0,
  data: {
    total: number;
    list: Array<{
      id: string;
      nickname: string;
      avatar: string;
      birthday: string;
      gender: string;
      city: string;
      interests: string[];
      commonInterests: string[];
      bio: string;
      canGreet: boolean;        // 是否可以搭话
      hasGreeted: boolean;      // 是否已搭话
    }>;
  }
}
```

#### 4.3.2 获取推荐搭子

```
GET /api/partners/recommendations
```

**Query参数**

```typescript
{
  page?: number;
  pageSize?: number;
}
```

**响应**

```typescript
{
  code: 0,
  data: {
    total: number;
    list: Array<{
      id: string;
      nickname: string;
      avatar: string;
      birthday: string;
      gender: string;
      city: string;
      distance: number;        // 距离（公里）
      tags: string[];          // 关联标签（如同校、同公司）
      commonInterests: string[];
      bio: string;
      matchScore: number;       // 匹配分
    }>;
  }
}
```

#### 4.3.3 发送搭话

```
POST /api/partners/greet
```

**请求体**

```typescript
{
  toUserId: string;      // 对方用户ID
  content?: string;      // 自定义搭话内容（可选）
  templateId?: number;   // 搭话模板ID（可选）
}
```

**响应**

```typescript
{
  code: 0,
  message: '搭话成功',
  data: null
}
```

#### 4.3.4 获取搭话记录

```
GET /api/partners/greetings
```

**Query参数**

```typescript
{
  type: 'sent' | 'received';  // 发送的/收到的
  page?: number;
  pageSize?: number;
}
```

### 4.4 活动模块API

#### 4.4.1 获取活动列表

```
GET /api/activities
```

**Query参数**

```typescript
{
  type?: string;           // 活动类型
  city?: string;           // 城市
  page?: number;
  pageSize?: number;
}
```

#### 4.4.2 发布活动

```
POST /api/activities
```

**请求体**

```typescript
{
  type: string;
  title: string;
  description?: string;
  time: string;            // ISO日期
  location: {
    name: string;
    address: string;
    latitude: number;
    longitude: number;
  };
  maxParticipants: number;
  tags?: string[];
}
```

#### 4.4.3 报名活动

```
POST /api/activities/:activityId/join
```

#### 4.4.4 活动打卡

```
POST /api/activities/:activityId/checkin
```

**请求体**

```typescript
{
  photos?: string[];
  review?: string;
  rating: number;
}
```

---

## 五、项目规范

### 5.1 Git提交规范

#### Commit Message格式

```
<type>(<scope>): <subject>

<body>

<footer>
```

#### Type类型

| Type | 说明 |
|------|------|
| feat | 新功能 |
| fix | Bug修复 |
| docs | 文档更新 |
| style | 代码格式（不影响功能） |
| refactor | 重构（不是新功能也不是修复） |
| perf | 性能优化 |
| test | 测试相关 |
| chore | 构建/工具相关 |

#### 示例

```bash
# 新功能
git commit -m "feat(users): add WeChat login support"

# Bug修复
git commit -m "fix(partners): fix greeting count not updating"

# 文档
git commit -m "docs: update API documentation"
```

### 5.2 代码风格规范

#### TypeScript规范

```typescript
// ✅ 使用interface定义对象类型
interface User {
  id: string;
  nickname: string;
  avatar: string;
}

// ✅ 使用type定义联合类型、工具类型
type Gender = 'male' | 'female' | 'secret';
type UserPartial = Partial<User>;

// ✅ 使用枚举定义常量
enum UserStatus {
  Active = 1,
  Inactive = 0
}

// ❌ 避免使用any，使用unknown并做好类型守卫
function parseJSON(json: string): unknown {
  return JSON.parse(json);
}
```

#### Vue 3 Composition API规范

```typescript
// ✅ 使用<script setup>语法
<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';

// 类型定义
interface Props {
  userId: string;
}

// Props
const props = defineProps<Props>();

// Emits
const emit = defineEmits<{
  (e: 'update', value: string): void;
}>();

// Ref
const loading = ref(false);

// Computed
const userName = computed(() => props.userId);

// Methods
const fetchData = async () => {
  loading.value = true;
  try {
    // ...
  } finally {
    loading.value = false;
  }
};

// Lifecycle
onMounted(() => {
  fetchData();
});
</script>

<template>
  <div>{{ userName }}</div>
</template>
```

#### NestJS模块规范

```typescript
// ✅ 每个模块包含完整的MVC结构
// users.module.ts
@Module({
  imports: [MongooseModule.forFeature([{ name: User.name, schema: UserSchema }])],
  controllers: [UsersController],
  providers: [UsersService],
  exports: [UsersService]
})
export class UsersModule {}

// ✅ DTO使用class-validator验证
export class CreateUserDto {
  @IsString()
  @MinLength(2)
  @MaxLength(12)
  nickname: string;

  @IsEnum(['male', 'female', 'secret'])
  gender: string;

  @IsDateString()
  birthday: string;
}
```

### 5.3 目录结构规范

```
# 每个模块的目录结构（NestJS风格）
├── modules/
│   └── users/
│       ├── dto/                  # 数据传输对象
│       │   ├── create-user.dto.ts
│       │   ├── update-user.dto.ts
│       │   └── index.ts
│       ├── schemas/              # 数据库Schema
│       │   ├── user.schema.ts
│       │   └── index.ts
│       ├── interfaces/            # 接口定义
│       │   └── user.interface.ts
│       ├── users.controller.ts   # 控制器
│       ├── users.service.ts      # 服务
│       ├── users.module.ts       # 模块
│       └── users.repository.ts   # 数据访问层
```

---

## 六、部署方案

### 6.1 Docker部署架构

```yaml
# docker-compose.yml
version: '3.8'

services:
  # 后端服务
  api:
    build:
      context: ./server
      dockerfile: Dockerfile
    container_name: birthday-partner-api
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - MONGODB_URI=mongodb://mongo:27017/birthday_partner
      - REDIS_HOST=redis
      - REDIS_PORT=6379
    depends_on:
      - mongo
      - redis
    restart: always

  # MongoDB数据库
  mongo:
    image: mongo:6.0
    container_name: birthday-partner-mongo
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db
    restart: always

  # Redis缓存
  redis:
    image: redis:7-alpine
    container_name: birthday-partner-redis
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: always

  # Nginx反向代理
  nginx:
    image: nginx:alpine
    container_name: birthday-partner-nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./nginx/ssl:/etc/nginx/ssl
      - ./h5_dist:/usr/share/nginx/html
    depends_on:
      - api
    restart: always

volumes:
  mongo_data:
  redis_data:
```

### 6.2 Nginx配置

```nginx
# nginx/nginx.conf
events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    # H5应用
    server {
        listen 80;
        server_name yourdomain.com;
        root /usr/share/nginx/html;
        index index.html;

        # H5路由history模式支持
        location / {
            try_files $uri $uri/ /index.html;
        }

        # API代理
        location /api/ {
            proxy_pass http://api:3000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }

        # SSL配置（生产环境）
        # listen 443 ssl;
        # ssl_certificate /etc/nginx/ssl/cert.pem;
        # ssl_certificate_key /etc/nginx/ssl/key.pem;
    }
}
```

### 6.3 部署流程

#### 开发环境部署

```bash
# 1. 启动所有服务
docker-compose up -d

# 2. 查看日志
docker-compose logs -f

# 3. 停止服务
docker-compose down
```

#### 生产环境部署

```bash
# 1. 构建前端
cd apps/h5
pnpm install
pnpm build

# 2. 构建后端
cd ../../server
docker build -t birthday-partner-api:latest .

# 3. 部署
docker-compose -f docker-compose.prod.yml up -d
```

---

## 七、开发环境搭建

### 7.1 环境要求

| 软件 | 版本要求 | 说明 |
|------|---------|------|
| Node.js | ^18.0 | 后端运行环境 |
| pnpm | ^8.0 | 包管理器 |
| Docker | ^24.0 | 容器化 |
| MongoDB | ^6.0 | 数据库 |
| Redis | ^7.0 | 缓存 |
| Git | 最新版 | 版本控制 |

### 7.2 快速开始

```bash
# 1. 克隆项目
git clone <repository-url>
cd birthday-partner

# 2. 安装依赖（根目录）
pnpm install

# 3. 启动数据库服务（Docker）
docker-compose up -d mongo redis

# 4. 启动后端开发服务器
cd server
pnpm start:dev

# 5. 启动H5开发服务器（新终端）
cd apps/h5
pnpm dev
```

---

## 八、测试策略

### 8.1 测试分层

| 测试类型 | 覆盖率目标 | 执行时机 |
|---------|-----------|---------|
| **单元测试** | 70%+ | 每次提交 |
| **集成测试** | 50%+ | 每次PR |
| **E2E测试** | 核心流程 | 每周 |

### 8.2 测试工具

| 类型 | 工具 | 说明 |
|------|------|------|
| **单元测试** | Jest + @nestjs/testing | NestJS官方推荐 |
| **API测试** | Supertest | HTTP断言 |
| **E2E测试** | Playwright | 跨浏览器测试 |
| **组件测试** | Vue Test Utils | Vue组件测试 |

---

## 九、安全考虑

### 9.1 API安全

- ✅ 所有API强制HTTPS
- ✅ JWT Token认证
- ✅ Token有效期24小时，自动刷新
- ✅ 请求频率限制（100次/分钟）
- ✅ 输入参数严格验证
- ✅ SQL注入防护（MongoDB参数化查询）
- ✅ XSS防护（输出编码）

### 9.2 数据安全

- ✅ 用户敏感信息加密存储
- ✅ 数据库定期备份
- ✅ Redis数据持久化
- ✅ 日志脱敏处理

### 9.3 隐私合规

- ✅ 用户位置信息仅用于同城匹配
- ✅ 隐私政策页面
- ✅ 用户协议
- ✅ 注销账户功能

---

## 十、后续迭代规划

### 第一版 MVP (当前)

- 用户注册/登录
- 今日寿星列表
- 私信搭话
- 个人资料管理

### 第二版扩展

- 同城筛选
- 背景关联匹配
- 活动发布/报名
- 活动打卡

### 第三版完善

- 活动群聊
- 搭子等级系统
- 实名认证
- 更多社交场景

---

**文档状态**: V1.0完成，待用户审核确认

**下一步行动**: 
1. 用户审核技术规格文档
2. 创建详细的开发计划
3. 开始项目初始化

