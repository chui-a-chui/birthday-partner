# 生日搭子 - MVP开发计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 在1-2个月内完成生日搭子MVP产品开发，包含H5移动端和抖音小程序双端

**Architecture:** 基于Monorepo架构，前端使用Vue 3 + Vite，后端使用NestJS + MongoDB + Redis，共享类型定义和API客户端

**Tech Stack:** Vue 3 + Vite + TypeScript + Pinia + Vant 4 (前端) | NestJS + MongoDB + Redis (后端)

---

## 里程碑概览

| 阶段 | 时间 | 交付物 |
|------|------|--------|
| **第一阶段** | 第1周 | Monorepo项目结构 + 后端基础框架 |
| **第二阶段** | 第2-3周 | 用户模块 + 今日寿星列表 + 搭话功能 |
| **第三阶段** | 第4周 | H5前端开发 + UI完善 |
| **第四阶段** | 第5-7周 | 抖音小程序适配 + 测试优化 |
| **第五阶段** | 第8周 | 部署上线 + 抖音审核提交 |

---

## 第一阶段：项目初始化（第1周）

### 任务 1.1：初始化Monorepo项目结构

**Files:**
- Create: `package.json`
- Create: `pnpm-workspace.yaml`
- Create: `tsconfig.base.json`
- Create: `.gitignore`
- Create: `README.md`

**Tasks:**

- [ ] **Step 1: 创建根目录package.json**

```json
{
  "name": "birthday-partner",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "pnpm -r --parallel dev",
    "build": "pnpm -r build",
    "test": "pnpm -r test",
    "lint": "pnpm -r lint"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "pnpm": "^8.0.0"
  }
}
```

- [ ] **Step 2: 创建pnpm-workspace.yaml**

```yaml
packages:
  - 'apps/*'
  - 'packages/*'
  - 'server'
```

- [ ] **Step 3: 创建基础TypeScript配置**

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "ESNext",
    "moduleResolution": "node",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true
  }
}
```

- [ ] **Step 4: 创建.gitignore**

```gitignore
node_modules/
dist/
build/
*.log
.env
.env.local
.DS_Store
```

- [ ] **Step 5: 提交代码**

```bash
git add .
git commit -m "docs: initialize monorepo project structure"
```

---

### 任务 1.2：搭建后端基础框架

**Files:**
- Create: `server/package.json`
- Create: `server/tsconfig.json`
- Create: `server/src/main.ts`
- Create: `server/src/app.module.ts`
- Create: `server/Dockerfile`
- Create: `server/docker-compose.yml`

**Tasks:**

- [ ] **Step 1: 创建server/package.json**

```json
{
  "name": "@birthday-partner/server",
  "version": "1.0.0",
  "scripts": {
    "start": "nest start",
    "start:dev": "nest start --watch",
    "start:prod": "node dist/main"
  },
  "dependencies": {
    "@nestjs/common": "^10.0.0",
    "@nestjs/core": "^10.0.0",
    "@nestjs/platform-express": "^10.0.0",
    "@nestjs/mongoose": "^10.0.0",
    "@nestjs/jwt": "^10.0.0",
    "@nestjs/passport": "^10.0.0",
    "mongoose": "^8.0.0",
    "passport": "^0.7.0",
    "passport-jwt": "^4.0.0",
    "class-validator": "^0.14.0",
    "class-transformer": "^0.5.0",
    "ioredis": "^5.0.0"
  },
  "devDependencies": {
    "@nestjs/cli": "^10.0.0",
    "@types/node": "^20.0.0",
    "typescript": "^5.0.0"
  }
}
```

- [ ] **Step 2: 创建NestJS入口文件**

```typescript
// server/src/main.ts
import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  app.enableCors({
    origin: ['http://localhost:5173', 'https://yourdomain.com'],
    credentials: true
  });
  
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    transform: true
  }));
  
  await app.listen(3000);
}
bootstrap();
```

- [ ] **Step 3: 创建根模块**

```typescript
// server/src/app.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UsersModule } from './modules/users/users.module';

@Module({
  imports: [
    MongooseModule.forRoot(process.env.MONGODB_URI || 'mongodb://localhost:27017/birthday_partner'),
    UsersModule
  ],
  controllers: [],
  providers: []
})
export class AppModule {}
```

- [ ] **Step 4: 创建配置文件**

```typescript
// server/src/config/index.ts
export const config = {
  mongodbUri: process.env.MONGODB_URI || 'mongodb://localhost:27017/birthday_partner',
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379')
  },
  jwt: {
    secret: process.env.JWT_SECRET || 'your-secret-key',
    expiresIn: '24h'
  }
};
```

- [ ] **Step 5: 创建Docker配置**

```dockerfile
# server/Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install -g pnpm && pnpm install
COPY . .
RUN pnpm build
EXPOSE 3000
CMD ["pnpm", "start:prod"]
```

```yaml
# server/docker-compose.yml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      - MONGODB_URI=mongodb://mongo:27017/birthday_partner
      - REDIS_HOST=redis
  mongo:
    image: mongo:6.0
    ports:
      - "27017:27017"
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
```

- [ ] **Step 6: 提交代码**

```bash
git add server/
git commit -m "feat(server): initialize NestJS backend with MongoDB and Redis"
```

---

### 任务 1.3：搭建前端H5应用

**Files:**
- Create: `apps/h5/package.json`
- Create: `apps/h5/vite.config.ts`
- Create: `apps/h5/tsconfig.json`
- Create: `apps/h5/src/main.ts`
- Create: `apps/h5/src/App.vue`
- Create: `apps/h5/index.html`

**Tasks:**

- [ ] **Step 1: 创建H5应用的package.json**

```json
{
  "name": "@birthday-partner/h5",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vue-tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "vue": "^3.4.0",
    "vue-router": "^4.2.0",
    "pinia": "^2.1.0",
    "vant": "^4.8.0",
    "@birthday-partner/shared": "workspace:*",
    "@birthday-partner/api-client": "workspace:*"
  },
  "devDependencies": {
    "@vitejs/plugin-vue": "^5.0.0",
    "vite": "^5.0.0",
    "typescript": "^5.0.0",
    "vue-tsc": "^2.0.0"
  }
}
```

- [ ] **Step 2: 创建Vite配置**

```typescript
// apps/h5/vite.config.ts
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { resolve } from 'path';

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src')
    }
  },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true
      }
    }
  }
});
```

- [ ] **Step 3: 创建TypeScript配置**

```json
{
  "extends": "../../tsconfig.base.json",
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  },
  "include": ["src/**/*"]
}
```

- [ ] **Step 4: 创建入口文件**

```typescript
// apps/h5/src/main.ts
import { createApp } from 'vue';
import { createPinia } from 'pinia';
import App from './App.vue';
import router from './router';
import 'vant/lib/index.css';

const app = createApp(App);

app.use(createPinia());
app.use(router);

app.mount('#app');
```

- [ ] **Step 5: 创建App.vue**

```vue
<template>
  <router-view />
</template>

<script setup lang="ts">
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background-color: #f5f5f5;
}
</style>
```

- [ ] **Step 6: 创建HTML入口**

```html
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>生日搭子</title>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
```

- [ ] **Step 7: 创建基础路由**

```typescript
// apps/h5/src/router/index.ts
import { createRouter, createWebHistory } from 'vue-router';

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/home',
    name: 'Home',
    component: () => import('../pages/Home.vue')
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../pages/Login.vue')
  },
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('../pages/Profile.vue')
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;
```

- [ ] **Step 8: 提交代码**

```bash
git add apps/h5/
git commit -m "feat(h5): initialize Vue 3 + Vite frontend application"
```

---

### 任务 1.4：创建共享包

**Files:**
- Create: `packages/shared/package.json`
- Create: `packages/shared/tsconfig.json`
- Create: `packages/shared/src/types/user.ts`
- Create: `packages/shared/src/types/activity.ts`
- Create: `packages/shared/src/constants/api.ts`
- Create: `packages/shared/src/index.ts`

**Tasks:**

- [ ] **Step 1: 创建shared包的package.json**

```json
{
  "name": "@birthday-partner/shared",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc"
  },
  "devDependencies": {
    "typescript": "^5.0.0"
  }
}
```

- [ ] **Step 2: 创建用户类型定义**

```typescript
// packages/shared/src/types/user.ts
export interface User {
  id: string;
  openid: string;
  nickname: string;
  avatar: string;
  birthday: string;
  gender: 'male' | 'female' | 'secret';
  bio: string;
  interests: string[];
  location: UserLocation;
  background?: UserBackground;
  lastActiveAt: string;
  status: number;
}

export interface UserLocation {
  province: string;
  city: string;
  district: string;
  latitude: number;
  longitude: number;
  geohash: string;
}

export interface UserBackground {
  school?: {
    name: string;
    type: string;
    level: string;
    graduationYear?: number;
  };
  education?: {
    degree: string;
    major: string;
  };
  work?: {
    company: string;
    position: string;
    industry: string;
    isStudent: boolean;
  };
}

export interface UserLoginResponse {
  token: string;
  userInfo: {
    id: string;
    nickname: string;
    avatar: string;
    birthday: string;
    gender: string;
    isNewUser: boolean;
  };
}
```

- [ ] **Step 3: 创建活动类型定义**

```typescript
// packages/shared/src/types/activity.ts
export interface Activity {
  id: string;
  organizerId: string;
  type: ActivityType;
  title: string;
  description: string;
  time: string;
  location: ActivityLocation;
  maxParticipants: number;
  participants: string[];
  tags: string[];
  status: ActivityStatus;
  createdAt: string;
}

export type ActivityType = 'meal' | 'shopping' | 'entertainment' | 'sports' | 'travel' | 'birthday' | 'photo';

export type ActivityStatus = 0 | 1 | 2;

export interface ActivityLocation {
  name: string;
  address: string;
  latitude: number;
  longitude: number;
}
```

- [ ] **Step 4: 创建API常量**

```typescript
// packages/shared/src/constants/api.ts
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

export const API_PATHS = {
  // 用户模块
  USERS: {
    LOGIN: '/api/users/login',
    PROFILE: '/api/users/profile',
    UPDATE_PROFILE: '/api/users/profile',
    UPDATE_LOCATION: '/api/users/location'
  },
  
  // 搭子模块
  PARTNERS: {
    TODAY: '/api/partners/today',
    RECOMMENDATIONS: '/api/partners/recommendations',
    GREET: '/api/partners/greet',
    GREETINGS: '/api/partners/greetings'
  },
  
  // 活动模块
  ACTIVITIES: {
    LIST: '/api/activities',
    DETAIL: (id: string) => `/api/activities/${id}`,
    CREATE: '/api/activities',
    JOIN: (id: string) => `/api/activities/${id}/join`,
    CHECKIN: (id: string) => `/api/activities/${id}/checkin`
  }
} as const;
```

- [ ] **Step 5: 创建主入口文件**

```typescript
// packages/shared/src/index.ts
export * from './types/user';
export * from './types/activity';
export * from './constants/api';
```

- [ ] **Step 6: 提交代码**

```bash
git add packages/shared/
git commit -m "feat(shared): create shared types and constants package"
```

---

### 任务 1.5：创建API客户端包

**Files:**
- Create: `packages/api-client/package.json`
- Create: `packages/api-client/src/request.ts`
- Create: `packages/api-client/src/index.ts`

**Tasks:**

- [ ] **Step 1: 创建API客户端package.json**

```json
{
  "name": "@birthday-partner/api-client",
  "version": "1.0.0",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "scripts": {
    "build": "tsc"
  },
  "dependencies": {
    "axios": "^1.6.0"
  },
  "devDependencies": {
    "typescript": "^5.0.0",
    "@types/node": "^20.0.0"
  }
}
```

- [ ] **Step 2: 创建axios封装**

```typescript
// packages/api-client/src/request.ts
import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { API_BASE_URL } from '@birthday-partner/shared';

export interface ApiResponse<T = any> {
  code: number;
  message: string;
  data: T;
}

class Request {
  private instance: AxiosInstance;

  constructor() {
    this.instance = axios.create({
      baseURL: API_BASE_URL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json'
      }
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // 请求拦截器
    this.instance.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // 响应拦截器
    this.instance.interceptors.response.use(
      (response: AxiosResponse<ApiResponse>) => {
        if (response.data.code !== 0) {
          return Promise.reject(response.data);
        }
        return response.data;
      },
      (error) => {
        return Promise.reject(error);
      }
    );
  }

  public get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    return this.instance.get(url, config).then(res => res.data.data);
  }

  public post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    return this.instance.post(url, data, config).then(res => res.data.data);
  }

  public put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    return this.instance.put(url, data, config).then(res => res.data.data);
  }

  public delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    return this.instance.delete(url, config).then(res => res.data.data);
  }
}

export const request = new Request();
```

- [ ] **Step 3: 创建主入口**

```typescript
// packages/api-client/src/index.ts
export { request, ApiResponse } from './request';
```

- [ ] **Step 4: 提交代码**

```bash
git add packages/api-client/
git commit -m "feat(api-client): create API client package with axios"
```

---

## 第二阶段：核心功能开发（第2-3周）

### 任务 2.1：用户模块开发（后端）

**Files:**
- Create: `server/src/modules/users/dto/create-user.dto.ts`
- Create: `server/src/modules/users/dto/update-user.dto.ts`
- Create: `server/src/modules/users/schemas/user.schema.ts`
- Create: `server/src/modules/users/users.controller.ts`
- Create: `server/src/modules/users/users.service.ts`
- Create: `server/src/modules/users/users.module.ts`

**Tasks:**

- [ ] **Step 1: 创建用户DTO**

```typescript
// server/src/modules/users/dto/create-user.dto.ts
import { IsString, IsDateString, IsEnum, IsOptional, MinLength, MaxLength, IsArray, MaxArraySize } from 'class-validator';

export class CreateUserDto {
  @IsString()
  openid: string;

  @IsString()
  @MinLength(2)
  @MaxLength(12)
  nickname: string;

  @IsOptional()
  @IsString()
  avatar?: string;

  @IsDateString()
  birthday: string;

  @IsEnum(['male', 'female', 'secret'])
  gender: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  bio?: string;

  @IsOptional()
  @IsArray()
  @MaxArraySize(5)
  interests?: string[];
}
```

```typescript
// server/src/modules/users/dto/update-user.dto.ts
import { IsString, IsOptional, MaxLength, IsArray, MaxArraySize } from 'class-validator';

export class UpdateUserDto {
  @IsOptional()
  @IsString()
  @MaxLength(12)
  nickname?: string;

  @IsOptional()
  @IsString()
  avatar?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  bio?: string;

  @IsOptional()
  @IsArray()
  @MaxArraySize(5)
  interests?: string[];
}
```

- [ ] **Step 2: 创建用户Schema**

```typescript
// server/src/modules/users/schemas/user.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class User extends Document {
  @Prop({ required: true, unique: true })
  openid: string;

  @Prop({ required: true, minlength: 2, maxlength: 12 })
  nickname: string;

  @Prop({ default: '' })
  avatar: string;

  @Prop({ required: true, type: Date })
  birthday: Date;

  @Prop({ required: true, enum: ['male', 'female', 'secret'] })
  gender: string;

  @Prop({ default: '' })
  bio: string;

  @Prop({ type: [String], default: [] })
  interests: string[];

  @Prop({ required: true, type: Object })
  location: {
    province: string;
    city: string;
    district: string;
    latitude: number;
    longitude: number;
    geohash: string;
  };

  @Prop({ type: Object, default: null })
  background: any;

  @Prop({ default: Date.now })
  lastActiveAt: Date;

  @Prop({ default: 1, enum: [0, 1] })
  status: number;
}

export const UserSchema = SchemaFactory.createForClass(User);
UserSchema.index({ birthday: 1 });
UserSchema.index({ 'location.geohash': 1 });
UserSchema.index({ openid: 1 }, { unique: true });
```

- [ ] **Step 3: 创建用户服务**

```typescript
// server/src/modules/users/users.service.ts
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './schemas/user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<User>) {}

  async findByOpenid(openid: string): Promise<User | null> {
    return this.userModel.findOne({ openid }).exec();
  }

  async findById(id: string): Promise<User | null> {
    return this.userModel.findById(id).exec();
  }

  async create(createUserDto: CreateUserDto): Promise<User> {
    const user = new this.userModel(createUserDto);
    return user.save();
  }

  async update(id: string, updateUserDto: UpdateUserDto): Promise<User> {
    return this.userModel.findByIdAndUpdate(id, updateUserDto, { new: true }).exec();
  }

  async updateLocation(id: string, location: any): Promise<User> {
    return this.userModel.findByIdAndUpdate(
      id,
      { 
        location,
        lastActiveAt: new Date()
      },
      { new: true }
    ).exec();
  }
}
```

- [ ] **Step 4: 创建用户控制器**

```typescript
// server/src/modules/users/users.controller.ts
import { Controller, Get, Post, Put, Body, Param, UseGuards, Request } from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('login')
  async login(@Body() body: { code: string; platform: string }) {
    // 简化实现，实际应调用微信/抖音API获取openid
    const openid = `mock_openid_${body.code}`;
    let user = await this.usersService.findByOpenid(openid);
    
    if (!user) {
      const createDto: CreateUserDto = {
        openid,
        nickname: `用户${Date.now()}`,
        birthday: '2000-01-01',
        gender: 'secret'
      };
      user = await this.usersService.create(createDto);
    }

    const token = this.generateToken(user._id.toString());
    
    return {
      code: 0,
      data: {
        token,
        userInfo: {
          id: user._id,
          nickname: user.nickname,
          avatar: user.avatar,
          birthday: user.birthday,
          gender: user.gender,
          isNewUser: true
        }
      }
    };
  }

  @Get('profile/:userId')
  async getProfile(@Param('userId') userId: string) {
    const user = await this.usersService.findById(userId);
    if (!user) {
      return { code: 20001, message: '用户不存在', data: null };
    }

    return {
      code: 0,
      data: {
        id: user._id,
        nickname: user.nickname,
        avatar: user.avatar,
        birthday: user.birthday,
        gender: user.gender,
        bio: user.bio,
        interests: user.interests,
        location: {
          province: user.location?.province || '',
          city: user.location?.city || '',
          district: user.location?.district || ''
        }
      }
    };
  }

  @Put('profile')
  async updateProfile(@Body() updateUserDto: UpdateUserDto) {
    const user = await this.usersService.update(updateUserDto.id, updateUserDto);
    return {
      code: 0,
      data: user
    };
  }

  @Put('location')
  async updateLocation(@Body() body: { id: string; latitude: number; longitude: number; province: string; city: string; district: string }) {
    const user = await this.usersService.updateLocation(body.id, {
      ...body,
      geohash: this.encodeGeohash(body.latitude, body.longitude)
    });
    return {
      code: 0,
      data: user
    };
  }

  private generateToken(userId: string): string {
    // 简化实现，实际应使用JWT
    return Buffer.from(`${userId}:${Date.now()}`).toString('base64');
  }

  private encodeGeohash(lat: number, lng: number): string {
    // 简化实现，实际应使用GeoHash库
    return `${lat.toFixed(5)},${lng.toFixed(5)}`;
  }
}
```

- [ ] **Step 5: 创建用户模块**

```typescript
// server/src/modules/users/users.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from './schemas/user.schema';
import { UsersController } from './users.controller';
import { UsersService } from './users.service';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }])
  ],
  controllers: [UsersController],
  providers: [UsersService],
  exports: [UsersService]
})
export class UsersModule {}
```

- [ ] **Step 6: 提交代码**

```bash
git add server/src/modules/users/
git commit -m "feat(server): implement users module with CRUD operations"
```

---

### 任务 2.2：搭子模块开发（后端）

**Files:**
- Create: `server/src/modules/partners/dto/today-partners.dto.ts`
- Create: `server/src/modules/partners/dto/greet.dto.ts`
- Create: `server/src/modules/partners/schemas/greeting.schema.ts`
- Create: `server/src/modules/partners/partners.controller.ts`
- Create: `server/src/modules/partners/partners.service.ts`
- Create: `server/src/modules/partners/partners.module.ts`

**Tasks:**

- [ ] **Step 1: 创建DTO**

```typescript
// server/src/modules/partners/dto/greet.dto.ts
import { IsString, IsNotEmpty } from 'class-validator';

export class GreetDto {
  @IsString()
  @IsNotEmpty()
  toUserId: string;

  @IsString()
  content?: string;

  @IsNumber()
  templateId?: number;
}
```

- [ ] **Step 2: 创建Schema**

```typescript
// server/src/modules/partners/schemas/greeting.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ timestamps: true })
export class Greeting extends Document {
  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  fromUserId: Types.ObjectId;

  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  toUserId: Types.ObjectId;

  @Prop({ required: true })
  content: string;

  @Prop({ default: 0, enum: [0, 1, 2] })
  status: number;

  @Prop()
  readAt: Date;
}

export const GreetingSchema = SchemaFactory.createForClass(Greeting);
GreetingSchema.index({ fromUserId: 1 });
GreetingSchema.index({ toUserId: 1 });
```

- [ ] **Step 3: 创建服务**

```typescript
// server/src/modules/partners/partners.service.ts
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { User } from '../users/schemas/user.schema';
import { Greeting } from './schemas/greeting.schema';

@Injectable()
export class PartnersService {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Greeting.name) private greetingModel: Model<Greeting>
  ) {}

  async getTodayPartners(userId: string, page = 1, pageSize = 20) {
    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();

    const query: any = {
      $expr: {
        $and: [
          { $eq: [{ $month: '$birthday' }, month] },
          { $eq: [{ $dayOfMonth: '$birthday' }, day] }
        ]
      },
      _id: { $ne: new Types.ObjectId(userId) }
    };

    const total = await this.userModel.countDocuments(query);
    const list = await this.userModel
      .find(query)
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .exec();

    return {
      total,
      list: list.map(user => ({
        id: user._id,
        nickname: user.nickname,
        avatar: user.avatar,
        birthday: user.birthday,
        gender: user.gender,
        city: user.location?.city || '未知',
        interests: user.interests,
        bio: user.bio
      }))
    };
  }

  async sendGreeting(fromUserId: string, toUserId: string, content?: string) {
    const greeting = new this.greetingModel({
      fromUserId: new Types.ObjectId(fromUserId),
      toUserId: new Types.ObjectId(toUserId),
      content: content || '嗨，我和你同一天生日，交个朋友吧！'
    });

    await greeting.save();
    return { code: 0, message: '搭话成功' };
  }

  async getGreetings(userId: string, type: 'sent' | 'received', page = 1, pageSize = 20) {
    const query: any = type === 'sent' 
      ? { fromUserId: new Types.ObjectId(userId) }
      : { toUserId: new Types.ObjectId(userId) };

    const total = await this.greetingModel.countDocuments(query);
    const list = await this.greetingModel
      .find(query)
      .populate(type === 'sent' ? 'toUserId' : 'fromUserId', 'nickname avatar')
      .sort({ createdAt: -1 })
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .exec();

    return {
      total,
      list: list.map(g => ({
        id: g._id,
        content: g.content,
        status: g.status,
        createdAt: g.createdAt,
        user: type === 'sent' ? g.toUserId : g.fromUserId
      }))
    };
  }
}
```

- [ ] **Step 4: 创建控制器**

```typescript
// server/src/modules/partners/partners.controller.ts
import { Controller, Get, Post, Body, Query, Param } from '@nestjs/common';
import { PartnersService } from './partners.service';

@Controller('partners')
export class PartnersController {
  constructor(private readonly partnersService: PartnersService) {}

  @Get('today')
  async getTodayPartners(
    @Query('userId') userId: string,
    @Query('page') page?: number,
    @Query('pageSize') pageSize?: number
  ) {
    const result = await this.partnersService.getTodayPartners(userId, page, pageSize);
    return { code: 0, data: result };
  }

  @Post('greet')
  async sendGreet(
    @Body() body: { fromUserId: string; toUserId: string; content?: string }
  ) {
    return this.partnersService.sendGreeting(body.fromUserId, body.toUserId, body.content);
  }

  @Get('greetings')
  async getGreetings(
    @Query('userId') userId: string,
    @Query('type') type: 'sent' | 'received',
    @Query('page') page?: number,
    @Query('pageSize') pageSize?: number
  ) {
    const result = await this.partnersService.getGreetings(userId, type, page, pageSize);
    return { code: 0, data: result };
  }
}
```

- [ ] **Step 5: 创建模块**

```typescript
// server/src/modules/partners/partners.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from '../users/schemas/user.schema';
import { Greeting, GreetingSchema } from './schemas/greeting.schema';
import { PartnersController } from './partners.controller';
import { PartnersService } from './partners.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Greeting.name, schema: GreetingSchema }
    ])
  ],
  controllers: [PartnersController],
  providers: [PartnersService]
})
export class PartnersModule {}
```

- [ ] **Step 6: 更新app.module.ts**

```typescript
// server/src/app.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UsersModule } from './modules/users/users.module';
import { PartnersModule } from './modules/partners/partners.module';

@Module({
  imports: [
    MongooseModule.forRoot(process.env.MONGODB_URI || 'mongodb://localhost:27017/birthday_partner'),
    UsersModule,
    PartnersModule
  ]
})
export class AppModule {}
```

- [ ] **Step 7: 提交代码**

```bash
git add server/src/modules/partners/
git commit -m "feat(server): implement partners module with today-list and greeting features"
```

---

### 任务 2.3：H5前端-首页开发

**Files:**
- Create: `apps/h5/src/pages/Home.vue`
- Create: `apps/h5/src/components/PartnerCard.vue`
- Create: `apps/h5/src/stores/user.ts`
- Create: `apps/h5/src/api/users.ts`
- Create: `apps/h5/src/api/partners.ts`

**Tasks:**

- [ ] **Step 1: 创建用户Store**

```typescript
// apps/h5/src/stores/user.ts
import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { User } from '@birthday-partner/shared';

export const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token') || '');
  const userInfo = ref<User | null>(null);

  const isLoggedIn = computed(() => !!token.value);

  function setToken(newToken: string) {
    token.value = newToken;
    localStorage.setItem('token', newToken);
  }

  function setUserInfo(info: User) {
    userInfo.value = info;
  }

  function logout() {
    token.value = '';
    userInfo.value = null;
    localStorage.removeItem('token');
  }

  return {
    token,
    userInfo,
    isLoggedIn,
    setToken,
    setUserInfo,
    logout
  };
});
```

- [ ] **Step 2: 创建API调用**

```typescript
// apps/h5/src/api/partners.ts
import { request } from '@birthday-partner/api-client';
import { API_PATHS } from '@birthday-partner/shared';

export const getTodayPartners = (userId: string, page = 1, pageSize = 20) => {
  return request.get(API_PATHS.PARTNERS.TODAY, {
    params: { userId, page, pageSize }
  });
};

export const sendGreet = (fromUserId: string, toUserId: string, content?: string) => {
  return request.post(API_PATHS.PARTNERS.GREET, {
    fromUserId,
    toUserId,
    content
  });
};
```

- [ ] **Step 3: 创建搭子卡片组件**

```vue
<!-- apps/h5/src/components/PartnerCard.vue -->
<template>
  <div class="partner-card">
    <div class="card-header">
      <van-image
        round
        width="60"
        height="60"
        :src="partner.avatar || defaultAvatar"
        class="avatar"
      />
      <div class="info">
        <div class="name">{{ partner.nickname }}</div>
        <div class="location">{{ partner.city }}</div>
      </div>
    </div>
    
    <div class="card-body">
      <div class="birthday">
        🎂 {{ formatBirthday(partner.birthday) }}
      </div>
      <div class="bio" v-if="partner.bio">
        {{ partner.bio }}
      </div>
      <van-tag
        v-for="interest in partner.interests"
        :key="interest"
        type="primary"
        size="small"
        class="interest-tag"
      >
        {{ interest }}
      </van-tag>
    </div>

    <div class="card-footer">
      <van-button
        type="primary"
        size="small"
        :loading="greeting"
        @click="handleGreet"
      >
        💌 私信搭话
      </van-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { showToast } from 'vant';
import type { User } from '@birthday-partner/shared';
import { sendGreet } from '../api/partners';

interface Props {
  partner: User;
  currentUserId: string;
}

const props = defineProps<Props>();
const emit = defineEmits(['greeted']);

const greeting = ref(false);
const defaultAvatar = 'https://fastly.jsdelivr.net/npm/@vant/assets/cat.jpeg';

const formatBirthday = (date: string) => {
  const d = new Date(date);
  return `${d.getMonth() + 1}月${d.getDate()}日`;
};

const handleGreet = async () => {
  greeting.value = true;
  try {
    await sendGreet(props.currentUserId, props.partner.id);
    showToast('搭话成功，等待对方回复~');
    emit('greeted', props.partner.id);
  } catch (error) {
    showToast('搭话失败，请重试');
  } finally {
    greeting.value = false;
  }
};
</script>

<style scoped>
.partner-card {
  background: white;
  border-radius: 16px;
  padding: 16px;
  margin: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.card-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.info {
  flex: 1;
}

.name {
  font-size: 18px;
  font-weight: 600;
  color: #333;
}

.location {
  font-size: 14px;
  color: #666;
  margin-top: 4px;
}

.card-body {
  margin-bottom: 12px;
}

.birthday {
  font-size: 14px;
  color: #FF6B6B;
  margin-bottom: 8px;
}

.bio {
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
  line-height: 1.4;
}

.interest-tag {
  margin-right: 8px;
  margin-top: 4px;
}

.card-footer {
  display: flex;
  justify-content: flex-end;
}
</style>
```

- [ ] **Step 4: 创建首页**

```vue
<!-- apps/h5/src/pages/Home.vue -->
<template>
  <div class="home-page">
    <van-nav-bar title="生日搭子" fixed />
    
    <div class="content">
      <div class="header-info">
        <h2>🎂 今日寿星</h2>
        <p>今天有 {{ total }} 位寿星和你同一天生日</p>
      </div>

      <van-pull-refresh v-model="refreshing" @refresh="onRefresh">
        <van-list
          v-model:loading="loading"
          :finished="finished"
          finished-text="没有更多了"
          @load="onLoad"
        >
          <PartnerCard
            v-for="partner in partners"
            :key="partner.id"
            :partner="partner"
            :current-user-id="userStore.userInfo?.id || ''"
            @greeted="handleGreeted"
          />
        </van-list>
      </van-pull-refresh>

      <van-empty v-if="!loading && partners.length === 0" description="暂无今日寿星" />
    </div>

    <van-tabbar route fixed>
      <van-tabbar-item to="/home" icon="friends-o">发现搭子</van-tabbar-item>
      <van-tabbar-item to="/profile" icon="user-o">个人中心</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { useUserStore } from '../stores/user';
import { getTodayPartners } from '../api/partners';
import PartnerCard from '../components/PartnerCard.vue';
import type { User } from '@birthday-partner/shared';

const userStore = useUserStore();

const partners = ref<User[]>([]);
const loading = ref(false);
const finished = ref(false);
const refreshing = ref(false);
const page = ref(1);
const total = ref(0);

const onLoad = async () => {
  try {
    const result = await getTodayPartners(
      userStore.userInfo?.id || '',
      page.value,
      20
    );
    
    partners.value.push(...result.list);
    total.value = result.total;
    
    if (partners.value.length >= result.total) {
      finished.value = true;
    } else {
      page.value++;
    }
  } catch (error) {
    console.error('获取今日寿星失败', error);
  } finally {
    loading.value = false;
  }
};

const onRefresh = async () => {
  partners.value = [];
  page.value = 1;
  finished.value = false;
  loading.value = true;
  await onLoad();
  refreshing.value = false;
};

const handleGreeted = (userId: string) => {
  const index = partners.value.findIndex(p => p.id === userId);
  if (index !== -1) {
    // 可以标记已搭话
  }
};

onMounted(() => {
  if (!userStore.isLoggedIn) {
    // 跳转到登录页
  }
});
</script>

<style scoped>
.home-page {
  min-height: 100vh;
  background: #f5f5f5;
  padding-top: 46px;
  padding-bottom: 50px;
}

.content {
  padding: 12px;
}

.header-info {
  text-align: center;
  padding: 20px 0;
}

.header-info h2 {
  font-size: 24px;
  color: #FF6B6B;
  margin-bottom: 8px;
}

.header-info p {
  font-size: 14px;
  color: #666;
}
</style>
```

- [ ] **Step 5: 创建登录页**

```vue
<!-- apps/h5/src/pages/Login.vue -->
<template>
  <div class="login-page">
    <div class="logo">
      <h1>🎂 生日搭子</h1>
      <p>生日不孤单，同城找搭子</p>
    </div>

    <div class="login-form">
      <van-form @submit="onSubmit">
        <van-cell-group inset>
          <van-field
            v-model="nickname"
            name="nickname"
            label="昵称"
            placeholder="请输入昵称"
            :rules="[{ required: true, message: '请输入昵称' }]"
          />
          <van-field
            v-model="birthday"
            is-link
            readonly
            name="birthday"
            label="生日"
            placeholder="请选择生日"
            @click="showBirthdayPicker = true"
          />
          <van-field name="gender" label="性别">
            <template #input>
              <van-radio-group v-model="gender" direction="horizontal">
                <van-radio name="male">男</van-radio>
                <van-radio name="female">女</van-radio>
              </van-radio-group>
            </template>
          </van-field>
        </van-cell-group>
        
        <div style="margin: 16px;">
          <van-button round block type="primary" native-type="submit" :loading="loading">
            登录
          </van-button>
        </div>
      </van-form>
    </div>

    <van-popup v-model:show="showBirthdayPicker" position="bottom">
      <van-date-picker
        v-model="currentDate"
        :min-date="minDate"
        :max-date="maxDate"
        @confirm="onConfirmBirthday"
      />
    </van-popup>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { showToast } from 'vant';
import { useUserStore } from '../stores/user';

const router = useRouter();
const userStore = useUserStore();

const nickname = ref('');
const birthday = ref('');
const gender = ref('secret');
const loading = ref(false);
const showBirthdayPicker = ref(false);
const currentDate = ref(['2000', '01', '01']);

const minDate = new Date(1970, 0, 1);
const maxDate = new Date();

const onConfirmBirthday = ({ selectedValues }: any) => {
  birthday.value = selectedValues.join('-');
  showBirthdayPicker.value = false;
};

const onSubmit = async () => {
  loading.value = true;
  try {
    // 模拟登录
    const mockToken = `token_${Date.now()}`;
    const mockUser = {
      id: `user_${Date.now()}`,
      nickname: nickname.value,
      avatar: '',
      birthday: birthday.value,
      gender: gender.value
    };

    userStore.setToken(mockToken);
    userStore.setUserInfo(mockUser as any);
    
    showToast('登录成功');
    router.push('/home');
  } catch (error) {
    showToast('登录失败');
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 20px;
  background: linear-gradient(135deg, #FF6B6B 0%, #FFA07A 100%);
}

.logo {
  text-align: center;
  margin-bottom: 40px;
}

.logo h1 {
  font-size: 32px;
  color: white;
  margin-bottom: 12px;
}

.logo p {
  font-size: 16px;
  color: rgba(255, 255, 255, 0.9);
}

.login-form {
  background: white;
  border-radius: 16px;
  padding: 20px 0;
}
</style>
```

- [ ] **Step 6: 创建个人中心页**

```vue
<!-- apps/h5/src/pages/Profile.vue -->
<template>
  <div class="profile-page">
    <van-nav-bar title="个人中心" fixed />
    
    <div class="content">
      <van-cell-group inset>
        <van-cell title="头像">
          <template #value>
            <van-image
              round
              width="50"
              height="50"
              :src="userInfo?.avatar || defaultAvatar"
            />
          </template>
        </van-cell>
        <van-cell title="昵称" :value="userInfo?.nickname || '-'" />
        <van-cell title="生日" :value="formatBirthday(userInfo?.birthday)" />
        <van-cell title="性别" :value="formatGender(userInfo?.gender)" />
      </van-cell-group>

      <van-cell-group inset title="背景信息" style="margin-top: 12px;">
        <van-cell title="学校" is-link to="/profile/school" />
        <van-cell title="公司" is-link to="/profile/work" />
      </van-cell-group>

      <van-cell-group inset title="设置" style="margin-top: 12px;">
        <van-cell title="兴趣标签" is-link to="/profile/interests" />
        <van-cell title="位置权限" is-link @click="updateLocation" />
      </van-cell-group>

      <div style="margin: 20px;">
        <van-button block type="default" @click="handleLogout">
          退出登录
        </van-button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRouter } from 'vue-router';
import { showToast } from 'vant';
import { useUserStore } from '../stores/user';

const router = useRouter();
const userStore = useUserStore();

const userInfo = computed(() => userStore.userInfo);
const defaultAvatar = 'https://fastly.jsdelivr.net/npm/@vant/assets/cat.jpeg';

const formatBirthday = (date?: string) => {
  if (!date) return '-';
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const formatGender = (gender?: string) => {
  const map: Record<string, string> = {
    male: '男',
    female: '女',
    secret: '保密'
  };
  return map[gender || 'secret'] || '-';
};

const updateLocation = () => {
  // 简化实现，实际应调用地理定位API
  showToast('位置更新成功');
};

const handleLogout = () => {
  userStore.logout();
  showToast('已退出登录');
  router.push('/login');
};
</script>

<style scoped>
.profile-page {
  min-height: 100vh;
  background: #f5f5f5;
  padding-top: 46px;
}

.content {
  padding: 12px;
}
</style>
```

- [ ] **Step 7: 提交代码**

```bash
git add apps/h5/
git commit -m "feat(h5): implement home page, login page, and profile page"
```

---

## 第三阶段：抖音小程序适配（第4-5周）

### 任务 3.1：初始化抖音小程序项目

**Files:**
- Create: `apps/miniprogram/package.json`
- Create: `apps/miniprogram/project.config.json`
- Create: `apps/miniprogram/src/app.json`
- Create: `apps/miniprogram/src/app.ts`
- Create: `apps/miniprogram/src/app.css`

**Tasks:**

- [ ] **Step 1: 创建小程序package.json**

```json
{
  "name": "@birthday-partner/miniprogram",
  "version": "1.0.0",
  "scripts": {
    "dev": "ddt dev",
    "build": "ddt build"
  },
  "dependencies": {
    "@birthday-partner/shared": "workspace:*",
    "@birthday-partner/api-client": "workspace:*"
  },
  "devDependencies": {
    "typescript": "^5.0.0"
  }
}
```

- [ ] **Step 2: 创建小程序配置**

```json
{
  "appid": "your-appid",
  "projectname": "birthday-partner",
  "compileType": "miniprogram",
  "setting": {
    "urlCheck": false,
    "es6": true,
    "enhance": true
  }
}
```

- [ ] **Step 3: 创建app.json**

```json
{
  "pages": [
    "pages/index/index",
    "pages/profile/profile"
  ],
  "window": {
    "navigationBarTitleText": "生日搭子",
    "navigationBarBackgroundColor": "#FF6B6B",
    "navigationBarTextStyle": "white"
  },
  "tabBar": {
    "color": "#666666",
    "selectedColor": "#FF6B6B",
    "backgroundColor": "#ffffff",
    "list": [
      {
        "pagePath": "pages/index/index",
        "text": "发现搭子"
      },
      {
        "pagePath": "pages/profile/profile",
        "text": "个人中心"
      }
    ]
  }
}
```

- [ ] **Step 4: 提交代码**

```bash
git add apps/miniprogram/
git commit -m "feat(miniprogram): initialize Douyin miniprogram project"
```

---

### 任务 3.2：迁移H5代码到小程序

**Tasks:**

- [ ] **Step 1: 复制并适配H5的API调用层**
  - 将 `apps/h5/src/api/` 复制到 `apps/miniprogram/src/api/`
  - 适配axios为小程序request API

- [ ] **Step 2: 复制并适配页面组件**
  - 将H5的页面组件复制到小程序的pages目录
  - 适配Vant为小程序适配版本（Vant Weapp）

- [ ] **Step 3: 配置小程序tabBar和路由**
  - 配置app.json的pages和tabBar

- [ ] **Step 4: 适配地理定位API**
  - 使用小程序的 `tt.getLocation()` 替代浏览器的 `navigator.geolocation`

- [ ] **Step 5: 适配登录流程**
  - 使用小程序的 `tt.login()` 获取code

- [ ] **Step 6: 提交代码**

```bash
git add apps/miniprogram/
git commit -m "feat(miniprogram): migrate H5 features to Douyin miniprogram"
```

---

## 第四阶段：测试与优化（第6-7周）

### 任务 4.1：后端单元测试

**Files:**
- Create: `server/test/users.service.spec.ts`
- Create: `server/test/partners.service.spec.ts`

**Tasks:**

- [ ] **Step 1: 安装测试依赖**

```bash
cd server
pnpm add -D jest @nestjs/testing ts-jest @types/jest
```

- [ ] **Step 2: 创建测试配置**

```typescript
// server/jest.config.ts
export default {
  moduleFileExtensions: ['js', 'json', 'ts'],
  rootDir: '.',
  testRegex: '.*\\.spec\\.ts$',
  transform: {
    '^.+\\.(t|j)s$': 'ts-jest'
  },
  collectCoverageFrom: ['src/**/*.(t|j)s'],
  coverageDirectory: '../coverage'
};
```

- [ ] **Step 3: 编写用户服务测试**

```typescript
// server/test/users.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { getModelToken } from '@nestjs/mongoose';
import { UsersService } from '../src/modules/users/users.service';
import { User } from '../src/modules/users/schemas/user.schema';

describe('UsersService', () => {
  let service: UsersService;
  const mockUser = {
    _id: '123',
    openid: 'test_openid',
    nickname: '测试用户',
    avatar: '',
    birthday: new Date('2000-01-01'),
    gender: 'male',
    bio: '',
    interests: [],
    location: {
      province: '上海',
      city: '上海市',
      district: '徐汇区',
      latitude: 31.2,
      longitude: 121.4,
      geohash: 'wtw3sj0'
    },
    status: 1
  };

  const mockUserModel = {
    findOne: jest.fn().mockResolvedValue(mockUser),
    findById: jest.fn().mockResolvedValue(mockUser),
    create: jest.fn().mockResolvedValue(mockUser),
    findByIdAndUpdate: jest.fn().mockResolvedValue(mockUser)
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        {
          provide: getModelToken(User.name),
          useValue: mockUserModel
        }
      ]
    }).compile();

    service = module.get<UsersService>(UsersService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should find user by openid', async () => {
    const result = await service.findByOpenid('test_openid');
    expect(result).toEqual(mockUser);
    expect(mockUserModel.findOne).toHaveBeenCalledWith({ openid: 'test_openid' });
  });

  it('should create a new user', async () => {
    const createDto = {
      openid: 'new_openid',
      nickname: '新用户',
      birthday: '2000-01-01',
      gender: 'female'
    };
    const result = await service.create(createDto);
    expect(result).toEqual(mockUser);
  });
});
```

- [ ] **Step 4: 运行测试**

```bash
cd server
pnpm test
```

- [ ] **Step 5: 提交代码**

```bash
git add server/test/
git commit -m "test(server): add unit tests for users and partners services"
```

---

### 任务 4.2：前端E2E测试

**Tasks:**

- [ ] **Step 1: 安装Playwright**

```bash
pnpm add -D @playwright/test
npx playwright install
```

- [ ] **Step 2: 创建E2E测试配置**

```typescript
// apps/h5/e2e.config.ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:5173',
    trace: 'on-first-retry'
  },
  webServer: {
    command: 'pnpm dev',
    url: 'http://localhost:5173',
    reuseExistingServer: !process.env.CI
  }
});
```

- [ ] **Step 3: 编写登录流程测试**

```typescript
// apps/h5/tests/login.spec.ts
import { test, expect } from '@playwright/test';

test.describe('登录流程', () => {
  test('应该能够填写表单并提交', async ({ page }) => {
    await page.goto('/login');
    
    // 填写昵称
    await page.fill('input[name="nickname"]', '测试用户');
    
    // 选择生日
    await page.click('text=请选择生日');
    await page.click('text=确认');
    
    // 选择性别
    await page.click('text=男');
    
    // 提交
    await page.click('button:has-text("登录")');
    
    // 验证跳转
    await expect(page).toHaveURL('/home');
  });
});
```

- [ ] **Step 4: 运行E2E测试**

```bash
cd apps/h5
pnpm playwright test
```

- [ ] **Step 5: 提交代码**

```bash
git add apps/h5/tests/
git commit -m "test(h5): add E2E tests with Playwright"
```

---

## 第五阶段：部署上线（第8周）

### 任务 5.1：构建生产版本

**Tasks:**

- [ ] **Step 1: 构建H5应用**

```bash
cd apps/h5
pnpm build
```

- [ ] **Step 2: 构建后端服务**

```bash
cd server
pnpm build
```

- [ ] **Step 3: 创建nginx配置**

```nginx
# nginx/nginx.conf
server {
    listen 80;
    server_name yourdomain.com;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://api:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

- [ ] **Step 4: 提交代码**

```bash
git add nginx/
git commit -m "deploy: add nginx configuration for production"
```

---

### 任务 5.2：Docker部署

**Tasks:**

- [ ] **Step 1: 创建production的docker-compose**

```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  api:
    build:
      context: ./server
      dockerfile: Dockerfile
    environment:
      - NODE_ENV=production
      - MONGODB_URI=mongodb://mongo:27017/birthday_partner
      - REDIS_HOST=redis
      - REDIS_PORT=6379
    restart: always

  mongo:
    image: mongo:6.0
    volumes:
      - mongo_data:/data/db
    restart: always

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data
    restart: always

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf
      - ./apps/h5/dist:/usr/share/nginx/html
    depends_on:
      - api
    restart: always

volumes:
  mongo_data:
  redis_data:
```

- [ ] **Step 2: 部署到服务器**

```bash
# 在服务器上执行
docker-compose -f docker-compose.prod.yml up -d
```

- [ ] **Step 3: 验证部署**

```bash
# 检查容器状态
docker-compose ps

# 查看日志
docker-compose logs -f api

# 测试API
curl http://localhost:3000/api/partners/today
```

- [ ] **Step 4: 提交代码**

```bash
git add docker-compose.prod.yml
git commit -m "deploy: add production docker-compose configuration"
```

---

### 任务 5.3：提交抖音小程序审核

**Tasks:**

- [ ] **Step 1: 在抖音开发者平台创建应用**
  - 访问 https://open.douyin.com/platform
  - 创建小程序应用
  - 填写应用信息

- [ ] **Step 2: 配置服务器域名**
  - 在开发者工具中配置request合法域名
  - 配置为您的API服务器域名

- [ ] **Step 3: 提交审核**
  - 在开发者平台提交审核申请
  - 等待审核（通常7-15天）

- [ ] **Step 4: 发布上线**
  - 审核通过后发布小程序

---

## 开发检查清单

### 每日本地检查

- [ ] 代码编译无错误
- [ ] Git已提交当日代码
- [ ] 功能测试通过

### 每周检查

- [ ] 运行完整测试套件
- [ ] 代码审查
- [ ] 文档更新

### 部署前检查

- [ ] 所有测试通过
- [ ] 生产环境配置正确
- [ ] 备份数据库
- [ ] 监控告警配置

---

## 常见问题与解决方案

### Q1: MongoDB连接失败
**解决**: 检查MongoDB服务是否启动，URI是否正确

### Q2: 前端构建失败
**解决**: 检查依赖是否完整安装，TypeScript配置是否正确

### Q3: 小程序无法获取位置
**解决**: 在app.json中配置permission，提示用户授权

### Q4: API请求跨域
**解决**: 配置nginx反向代理，或后端开启CORS

### Q5: Token过期
**解决**: 实现token刷新机制，处理401错误并重定向登录

---

**Plan Status:** Complete

**Last Updated:** 2026-05-08

**Next Step:** Begin Phase 1 - Project Initialization
