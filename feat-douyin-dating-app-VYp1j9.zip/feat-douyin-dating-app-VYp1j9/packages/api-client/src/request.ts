import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { API_BASE_URL } from '@birthday-partner/shared';

export interface ApiResponse<T = unknown> {
  code: number;
  message: string;
  data: T;
}

export interface ApiError {
  code: number;
  message: string;
  data: null;
}

class Request {
  private instance: AxiosInstance;

  constructor() {
    this.instance = axios.create({
      baseURL: API_BASE_URL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    this.instance.interceptors.request.use(
      (config) => {
        const token = localStorage.getItem('token');
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        const platform = localStorage.getItem('platform') || 'h5';
        config.headers['X-Platform'] = platform;
        config.headers['X-Version'] = '1.0.0';
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    this.instance.interceptors.response.use(
      (response: AxiosResponse<ApiResponse>) => {
        if (response.data.code !== 0) {
          return Promise.reject({
            code: response.data.code,
            message: response.data.message,
            data: null,
          } as ApiError);
        }
        return response;
      },
      (error) => {
        if (error.response) {
          return Promise.reject({
            code: error.response.status,
            message: error.response.data?.message || '请求失败',
            data: null,
          } as ApiError);
        }
        return Promise.reject({
          code: -1,
          message: error.message || '网络错误',
          data: null,
        } as ApiError);
      }
    );
  }

  public get<T = unknown>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<T> {
    return this.instance
      .get<ApiResponse<T>>(url, config)
      .then((res) => res.data.data);
  }

  public post<T = unknown>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<T> {
    return this.instance
      .post<ApiResponse<T>>(url, data, config)
      .then((res) => res.data.data);
  }

  public put<T = unknown>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<T> {
    return this.instance
      .put<ApiResponse<T>>(url, data, config)
      .then((res) => res.data.data);
  }

  public delete<T = unknown>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<T> {
    return this.instance
      .delete<ApiResponse<T>>(url, config)
      .then((res) => res.data.data);
  }
}

export const request = new Request();
