export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

export const API_PATHS = {
  USERS: {
    LOGIN: '/api/users/login',
    PROFILE: '/api/users/profile',
    UPDATE_PROFILE: '/api/users/profile',
    UPDATE_LOCATION: '/api/users/location',
  },

  PARTNERS: {
    TODAY: '/api/partners/today',
    RECOMMENDATIONS: '/api/partners/recommendations',
    GREET: '/api/partners/greet',
    GREETINGS: '/api/partners/greetings',
  },

  ACTIVITIES: {
    LIST: '/api/activities',
    DETAIL: (id: string) => `/api/activities/${id}`,
    CREATE: '/api/activities',
    JOIN: (id: string) => `/api/activities/${id}/join`,
    CHECKIN: (id: string) => `/api/activities/${id}/checkin`,
  },
} as const;

export const GREETING_TEMPLATES = [
  {
    id: 1,
    content: '嗨，我和你同一天生日，交个朋友吧！',
  },
  {
    id: 2,
    content: '哇！我们居然同年同月同日生，太巧了吧！',
  },
  {
    id: 3,
    content: '生日搭子看过来～你也喜欢过生日吗？',
  },
];

export const INTEREST_TAGS = [
  '美食',
  '摄影',
  '旅行',
  '电影',
  '阅读',
  '音乐',
  '运动',
  '游戏',
  '宠物',
  '美妆',
  '穿搭',
  '健身',
  '追星',
  '二次元',
  '户外',
];
