export type ActivityType =
  | 'meal'
  | 'shopping'
  | 'entertainment'
  | 'sports'
  | 'travel'
  | 'birthday'
  | 'photo';

export type ActivityStatus = 0 | 1 | 2;

export interface Activity {
  id: string;
  organizerId: string;
  type: ActivityType;
  title: string;
  description: string;
  time: string;
  location: ActivityLocation;
  maxParticipants: number;
  participants: string[];
  tags: string[];
  status: ActivityStatus;
  createdAt: string;
}

export interface ActivityLocation {
  name: string;
  address: string;
  latitude: number;
  longitude: number;
}

export interface ActivityCheckin {
  id: string;
  activityId: string;
  userId: string;
  photos: string[];
  review: string;
  rating: number;
  createdAt: string;
}

export const ACTIVITY_TYPE_MAP: Record<ActivityType, string> = {
  meal: '吃饭搭子',
  shopping: '逛街搭子',
  entertainment: '娱乐搭子',
  sports: '运动搭子',
  travel: '旅游搭子',
  birthday: '生日派对',
  photo: '拍照搭子',
};

export const ACTIVITY_TYPE_ICONS: Record<ActivityType, string> = {
  meal: '🍽️',
  shopping: '🛍️',
  entertainment: '🎮',
  sports: '🏃',
  travel: '✈️',
  birthday: '🎂',
  photo: '📷',
};
