export interface User {
  id: string;
  openid: string;
  nickname: string;
  avatar: string;
  birthday: string;
  gender: 'male' | 'female' | 'secret';
  bio: string;
  interests: string[];
  location: UserLocation;
  background?: UserBackground;
  lastActiveAt: string;
  status: number;
}

export interface UserLocation {
  province: string;
  city: string;
  district: string;
  latitude: number;
  longitude: number;
  geohash: string;
}

export interface UserBackground {
  school?: {
    name: string;
    type: string;
    level: string;
    graduationYear?: number;
  };
  education?: {
    degree: string;
    major: string;
  };
  work?: {
    company: string;
    position: string;
    industry: string;
    isStudent: boolean;
  };
}

export interface UserLoginResponse {
  token: string;
  userInfo: {
    id: string;
    nickname: string;
    avatar: string;
    birthday: string;
    gender: string;
    isNewUser: boolean;
  };
}

export interface UserProfile extends Omit<User, 'openid' | 'lastActiveAt'> {}
