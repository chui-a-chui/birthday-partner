import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { config } from './config';
import { UsersModule } from './modules/users/users.module';
import { PartnersModule } from './modules/partners/partners.module';

@Module({
  imports: [
    MongooseModule.forRoot(config.mongodbUri, {
      autoIndex: true,
    }),
    UsersModule,
    PartnersModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
