import { IsString, IsNotEmpty, IsOptional, IsNumber } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class GreetDto {
  @ApiProperty({ description: '对方用户ID' })
  @IsString()
  @IsNotEmpty()
  toUserId: string;

  @ApiPropertyOptional({ description: '搭话内容' })
  @IsOptional()
  @IsString()
  content?: string;

  @ApiPropertyOptional({ description: '搭话模板ID' })
  @IsOptional()
  @IsNumber()
  templateId?: number;
}
