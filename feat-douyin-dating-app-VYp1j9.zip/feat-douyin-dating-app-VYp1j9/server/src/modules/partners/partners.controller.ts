import { Controller, Get, Post, Body, Query } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiQuery } from '@nestjs/swagger';
import { PartnersService } from './partners.service';
import { GreetDto } from './dto/greet.dto';

@ApiTags('搭子模块')
@Controller('partners')
export class PartnersController {
  constructor(private readonly partnersService: PartnersService) {}

  @Get('today')
  @ApiOperation({ summary: '获取今日寿星列表' })
  @ApiQuery({ name: 'userId', required: true, description: '当前用户ID' })
  @ApiQuery({ name: 'page', required: false, description: '页码' })
  @ApiQuery({ name: 'pageSize', required: false, description: '每页数量' })
  @ApiQuery({ name: 'city', required: false, description: '城市筛选' })
  @ApiQuery({ name: 'gender', required: false, description: '性别筛选' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getTodayPartners(
    @Query('userId') userId: string,
    @Query('page') page?: number,
    @Query('pageSize') pageSize?: number,
    @Query('city') city?: string,
    @Query('gender') gender?: string,
  ) {
    const result = await this.partnersService.getTodayPartners(
      userId,
      page,
      pageSize,
      { city, gender },
    );

    return {
      code: 0,
      message: 'success',
      data: result,
    };
  }

  @Post('greet')
  @ApiOperation({ summary: '发送搭话' })
  @ApiResponse({ status: 200, description: '搭话成功' })
  async sendGreet(
    @Body() body: { fromUserId: string; toUserId: string; content?: string },
  ) {
    const result = await this.partnersService.sendGreeting(body.fromUserId, {
      toUserId: body.toUserId,
      content: body.content,
    });

    return result;
  }

  @Get('greetings')
  @ApiOperation({ summary: '获取搭话记录' })
  @ApiQuery({ name: 'userId', required: true, description: '用户ID' })
  @ApiQuery({ name: 'type', required: true, description: '类型：sent-发送的，received-收到的' })
  @ApiQuery({ name: 'page', required: false, description: '页码' })
  @ApiQuery({ name: 'pageSize', required: false, description: '每页数量' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getGreetings(
    @Query('userId') userId: string,
    @Query('type') type: 'sent' | 'received',
    @Query('page') page?: number,
    @Query('pageSize') pageSize?: number,
  ) {
    const result = await this.partnersService.getGreetings(
      userId,
      type,
      page,
      pageSize,
    );

    return {
      code: 0,
      message: 'success',
      data: result,
    };
  }
}
