import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { User } from '../../users/schemas/user.schema';
import { Greeting } from './schemas/greeting.schema';
import { GreetDto } from './dto/greet.dto';

const GREETING_TEMPLATES = [
  '嗨，我和你同一天生日，交个朋友吧！',
  '哇！我们居然同年同月同日生，太巧了吧！',
  '生日搭子看过来～你也喜欢过生日吗？',
];

@Injectable()
export class PartnersService {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Greeting.name) private greetingModel: Model<Greeting>,
  ) {}

  async getTodayPartners(
    userId: string,
    page = 1,
    pageSize = 20,
    filters?: { city?: string; gender?: string },
  ) {
    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();

    const matchStage: any = {
      $expr: {
        $and: [
          { $eq: [{ $month: '$birthday' }, month] },
          { $eq: [{ $dayOfMonth: '$birthday' }, day] },
        ],
      },
      _id: { $ne: new Types.ObjectId(userId) },
      status: 1,
    };

    if (filters?.gender) {
      matchStage.gender = filters.gender;
    }

    if (filters?.city) {
      matchStage['location.city'] = filters.city;
    }

    const total = await this.userModel.countDocuments(matchStage);
    const list = await this.userModel
      .aggregate([
        { $match: matchStage },
        { $skip: (page - 1) * pageSize },
        { $limit: pageSize },
        {
          $project: {
            _id: 1,
            nickname: 1,
            avatar: 1,
            birthday: 1,
            gender: 1,
            bio: 1,
            interests: 1,
            'location.city': 1,
          },
        },
      ])
      .exec();

    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

    return {
      total,
      today: todayStr,
      list: list.map((user) => ({
        id: user._id,
        nickname: user.nickname,
        avatar: user.avatar,
        birthday: user.birthday,
        gender: user.gender,
        bio: user.bio,
        interests: user.interests,
        city: user.location?.city || '未知',
      })),
    };
  }

  async sendGreeting(fromUserId: string, greetDto: GreetDto) {
    const greeting = new this.greetingModel({
      fromUserId: new Types.ObjectId(fromUserId),
      toUserId: new Types.ObjectId(greetDto.toUserId),
      content: greetDto.content || this.getRandomTemplate(),
      status: 0,
    });

    await greeting.save();

    return {
      code: 0,
      message: '搭话成功',
    };
  }

  async getGreetings(
    userId: string,
    type: 'sent' | 'received',
    page = 1,
    pageSize = 20,
  ) {
    const matchCondition =
      type === 'sent'
        ? { fromUserId: new Types.ObjectId(userId) }
        : { toUserId: new Types.ObjectId(userId) };

    const total = await this.greetingModel
      .countDocuments(matchCondition)
      .exec();
    const list = await this.greetingModel
      .aggregate([
        { $match: matchCondition },
        {
          $lookup: {
            from: 'users',
            let: {
              userId:
                type === 'sent' ? '$toUserId' : '$fromUserId',
            },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ['$_id', '$$userId'] },
                },
              },
              {
                $project: {
                  nickname: 1,
                  avatar: 1,
                  birthday: 1,
                },
              },
            ],
            as: 'user',
          },
        },
        { $unwind: '$user' },
        { $sort: { createdAt: -1 } },
        { $skip: (page - 1) * pageSize },
        { $limit: pageSize },
        {
          $project: {
            _id: 1,
            content: 1,
            status: 1,
            createdAt: 1,
            'user.nickname': 1,
            'user.avatar': 1,
          },
        },
      ])
      .exec();

    return {
      total,
      list: list.map((g) => ({
        id: g._id,
        content: g.content,
        status: g.status,
        createdAt: g.createdAt,
        user: {
          id: g.user._id,
          nickname: g.user.nickname,
          avatar: g.user.avatar,
        },
      })),
    };
  }

  private getRandomTemplate(): string {
    return GREETING_TEMPLATES[Math.floor(Math.random() * GREETING_TEMPLATES.length)];
  }
}
