import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ timestamps: true, collection: 'greetings' })
export class Greeting extends Document {
  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  fromUserId: Types.ObjectId;

  @Prop({ required: true, type: Types.ObjectId, ref: 'User' })
  toUserId: Types.ObjectId;

  @Prop({ required: true })
  content: string;

  @Prop({ default: 0, enum: [0, 1, 2] })
  status: number;

  @Prop()
  readAt: Date;
}

export const GreetingSchema = SchemaFactory.createForClass(Greeting);

GreetingSchema.index({ fromUserId: 1 });
GreetingSchema.index({ toUserId: 1 });
GreetingSchema.index({ toUserId: 1, status: 1 });
GreetingSchema.index({ createdAt: -1 });
