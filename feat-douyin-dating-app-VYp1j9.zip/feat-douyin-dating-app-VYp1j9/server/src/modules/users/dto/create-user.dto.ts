import {
  IsString,
  IsDateString,
  IsEnum,
  IsOptional,
  MinLength,
  MaxLength,
  IsArray,
  MaxArraySize,
  IsObject,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class LocationDto {
  @ApiPropertyOptional({ description: '省份' })
  @IsOptional()
  @IsString()
  province?: string;

  @ApiPropertyOptional({ description: '城市' })
  @IsOptional()
  @IsString()
  city?: string;

  @ApiPropertyOptional({ description: '区县' })
  @IsOptional()
  @IsString()
  district?: string;

  @ApiPropertyOptional({ description: '纬度' })
  @IsOptional()
  latitude?: number;

  @ApiPropertyOptional({ description: '经度' })
  @IsOptional()
  longitude?: number;

  @ApiPropertyOptional({ description: 'GeoHash编码' })
  @IsOptional()
  @IsString()
  geohash?: string;
}

export class CreateUserDto {
  @ApiProperty({ description: '微信/抖音openid' })
  @IsString()
  openid: string;

  @ApiProperty({ description: '昵称', minLength: 2, maxLength: 12 })
  @IsString()
  @MinLength(2)
  @MaxLength(12)
  nickname: string;

  @ApiPropertyOptional({ description: '头像URL' })
  @IsOptional()
  @IsString()
  avatar?: string;

  @ApiProperty({ description: '生日日期' })
  @IsDateString()
  birthday: string;

  @ApiProperty({ description: '性别', enum: ['male', 'female', 'secret'] })
  @IsEnum(['male', 'female', 'secret'])
  gender: string;

  @ApiPropertyOptional({ description: '自我介绍', maxLength: 100 })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  bio?: string;

  @ApiPropertyOptional({ description: '兴趣标签', type: [String] })
  @IsOptional()
  @IsArray()
  @MaxArraySize(5)
  interests?: string[];

  @ApiPropertyOptional({ description: '位置信息' })
  @IsOptional()
  @IsObject()
  location?: LocationDto;
}
