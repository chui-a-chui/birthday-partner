import {
  IsString,
  IsOptional,
  MaxLength,
  IsArray,
  MaxArraySize,
} from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';

export class UpdateUserDto {
  @ApiPropertyOptional({ description: '用户ID' })
  @IsString()
  id: string;

  @ApiPropertyOptional({ description: '昵称', minLength: 2, maxLength: 12 })
  @IsOptional()
  @IsString()
  @MaxLength(12)
  nickname?: string;

  @ApiPropertyOptional({ description: '头像URL' })
  @IsOptional()
  @IsString()
  avatar?: string;

  @ApiPropertyOptional({ description: '自我介绍', maxLength: 100 })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  bio?: string;

  @ApiPropertyOptional({ description: '兴趣标签', type: [String] })
  @IsOptional()
  @IsArray()
  @MaxArraySize(5)
  interests?: string[];
}
