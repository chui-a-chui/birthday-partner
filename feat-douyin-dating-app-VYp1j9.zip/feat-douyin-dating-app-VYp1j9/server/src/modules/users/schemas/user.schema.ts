import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true, collection: 'users' })
export class User extends Document {
  @Prop({ required: true, unique: true, index: true })
  openid: string;

  @Prop({ required: true, minlength: 2, maxlength: 12 })
  nickname: string;

  @Prop({ default: '' })
  avatar: string;

  @Prop({ required: true, type: Date })
  birthday: Date;

  @Prop({ required: true, enum: ['male', 'female', 'secret'] })
  gender: string;

  @Prop({ default: '' })
  bio: string;

  @Prop({ type: [String], default: [] })
  interests: string[];

  @Prop({ required: true, type: Object })
  location: {
    province: string;
    city: string;
    district: string;
    latitude: number;
    longitude: number;
    geohash: string;
  };

  @Prop({ type: Object, default: null })
  background: {
    school?: {
      name: string;
      type: string;
      level: string;
      graduationYear?: number;
    };
    education?: {
      degree: string;
      major: string;
    };
    work?: {
      company: string;
      position: string;
      industry: string;
      isStudent: boolean;
    };
  };

  @Prop({ default: Date.now })
  lastActiveAt: Date;

  @Prop({ default: 1, enum: [0, 1] })
  status: number;
}

export const UserSchema = SchemaFactory.createForClass(User);

UserSchema.index({ birthday: 1 });
UserSchema.index({ 'location.geohash': 1 });
UserSchema.index({ 'location.city': 1 });
