import { Controller, Get, Post, Put, Body, Param } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import * as crypto from 'crypto';

@ApiTags('用户模块')
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post('login')
  @ApiOperation({ summary: '用户登录' })
  @ApiResponse({ status: 200, description: '登录成功' })
  async login(
    @Body() body: { code: string; platform: string },
  ) {
    const openid = `mock_${body.platform}_${body.code}`;
    let user = await this.usersService.findByOpenid(openid);

    if (!user) {
      const createDto: CreateUserDto = {
        openid,
        nickname: `用户${Date.now()}`,
        birthday: '2000-01-01',
        gender: 'secret',
      };
      user = await this.usersService.create(createDto);
    }

    const token = this.generateToken(user._id.toString());

    return {
      code: 0,
      message: '登录成功',
      data: {
        token,
        userInfo: {
          id: user._id,
          nickname: user.nickname,
          avatar: user.avatar,
          birthday: user.birthday,
          gender: user.gender,
          isNewUser: true,
        },
      },
    };
  }

  @Get('profile/:userId')
  @ApiOperation({ summary: '获取用户资料' })
  @ApiResponse({ status: 200, description: '获取成功' })
  async getProfile(@Param('userId') userId: string) {
    const user = await this.usersService.findById(userId);

    if (!user) {
      return {
        code: 20001,
        message: '用户不存在',
        data: null,
      };
    }

    return {
      code: 0,
      data: {
        id: user._id,
        nickname: user.nickname,
        avatar: user.avatar,
        birthday: user.birthday,
        gender: user.gender,
        bio: user.bio,
        interests: user.interests,
        location: {
          province: user.location?.province || '',
          city: user.location?.city || '',
          district: user.location?.district || '',
        },
      },
    };
  }

  @Put('profile')
  @ApiOperation({ summary: '更新用户资料' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateProfile(@Body() updateUserDto: UpdateUserDto) {
    const user = await this.usersService.update(updateUserDto.id, {
      nickname: updateUserDto.nickname,
      avatar: updateUserDto.avatar,
      bio: updateUserDto.bio,
      interests: updateUserDto.interests,
    });

    return {
      code: 0,
      message: '更新成功',
      data: user,
    };
  }

  @Put('location')
  @ApiOperation({ summary: '更新位置信息' })
  @ApiResponse({ status: 200, description: '更新成功' })
  async updateLocation(
    @Body()
    body: {
      id: string;
      latitude: number;
      longitude: number;
      province: string;
      city: string;
      district: string;
    },
  ) {
    const geohash = this.encodeGeohash(body.latitude, body.longitude);

    const user = await this.usersService.updateLocation(body.id, {
      latitude: body.latitude,
      longitude: body.longitude,
      province: body.province,
      city: body.city,
      district: body.district,
      geohash,
    });

    return {
      code: 0,
      message: '更新成功',
      data: user,
    };
  }

  private generateToken(userId: string): string {
    const payload = `${userId}:${Date.now()}`;
    return Buffer.from(payload).toString('base64');
  }

  private encodeGeohash(lat: number, lng: number): string {
    return `${lat.toFixed(5)},${lng.toFixed(5)}`;
  }
}
