import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { User } from './schemas/user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<User>) {}

  async findByOpenid(openid: string): Promise<User | null> {
    return this.userModel.findOne({ openid }).exec();
  }

  async findById(id: string): Promise<User | null> {
    return this.userModel.findById(id).exec();
  }

  async create(createUserDto: CreateUserDto): Promise<User> {
    const user = new this.userModel({
      ...createUserDto,
      location: createUserDto.location || {
        province: '',
        city: '',
        district: '',
        latitude: 0,
        longitude: 0,
        geohash: '',
      },
    });
    return user.save();
  }

  async update(id: string, updateUserDto: UpdateUserDto): Promise<User | null> {
    return this.userModel
      .findByIdAndUpdate(id, updateUserDto, { new: true })
      .exec();
  }

  async updateLocation(
    id: string,
    location: {
      latitude: number;
      longitude: number;
      province: string;
      city: string;
      district: string;
      geohash?: string;
    },
  ): Promise<User | null> {
    return this.userModel
      .findByIdAndUpdate(
        id,
        {
          location,
          lastActiveAt: new Date(),
        },
        { new: true },
      )
      .exec();
  }
}
